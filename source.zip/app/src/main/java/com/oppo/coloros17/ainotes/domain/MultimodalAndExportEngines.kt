package com.oppo.coloros17.ainotes.domain

import com.oppo.coloros17.ainotes.data.model.DragDropPayload
import com.oppo.coloros17.ainotes.data.model.ExportFormat
import com.oppo.coloros17.ainotes.data.model.NoteEntity
import com.oppo.coloros17.ainotes.data.model.SpeakerSegment
import com.oppo.coloros17.ainotes.data.model.SparkInsight
import com.oppo.coloros17.ainotes.data.model.StructuredNoteResult
import com.oppo.coloros17.ainotes.data.model.StructuredTable
import kotlinx.coroutines.delay

/**
 * Provides full business logic skeletons for:
 * 1. Multimodal recording (Voice offline transcription + speaker diarization, Camera OCR scan, Video/Web link parser)
 * 2. AI Note Assistant (Formatting messy text into rich-text lists & tables)
 * 3. Structured Quick-Look Card (Adaptive self-contained HTML visualization card)
 * 4. Spark Moment ("灵光一刻" historical note scanner & golden quote extractor)
 * 5. Multi-format exporter (PDF, Word .docx, TXT, Image .png)
 * 6. Global Drag-and-Drop Smart Capsule parser ("智慧胶囊")
 */
class MultimodalAndExportEngines(
    private val hierarchicalSummarizer: HierarchicalSummarizer = HierarchicalSummarizer()
) {

    suspend fun runOfflineVoiceTranscriptionWithDiarization(durationSeconds: Int): List<SpeakerSegment> {
        delay(350)
        return listOf(
            SpeakerSegment(
                speakerId = "SPK_01",
                speakerName = "主讲人 (产品架构师)",
                timestampRange = "00:00 - 00:18",
                transcript = "ColorOS 17 AI 笔记不仅需要流体毛玻璃视觉，底层必须全面采用流式 I/O 处理超大文档。"
            ),
            SpeakerSegment(
                speakerId = "SPK_02",
                speakerName = "研发负责人 (Android)",
                timestampRange = "00:19 - 00:42",
                transcript = "同意，我们已经移除了所有文件大小限制，并且采用多层级滚动汇总算法保障长文总结不丢失任何段落。"
            ),
            SpeakerSegment(
                speakerId = "SPK_01",
                speakerName = "主讲人 (产品架构师)",
                timestampRange = "00:43 - " + String.format("%02d:%02d", durationSeconds / 60, durationSeconds % 60),
                transcript = "下一步重点联调智慧胶囊全局拖拽与结构化 HTML 速览图卡片。"
            )
        )
    }

    suspend fun performCameraDocumentOcrScan(sceneLabel: String): String {
        delay(280)
        return buildString {
            appendLine("【超清文档拍照扫描 OCR 结果 - $sceneLabel】")
            appendLine("1. 会议决议：Q4 全面升级端侧 7B 大模型离线推理引擎。")
            appendLine("2. 性能指标：首字响应延迟 (TTFT) 控制在 220ms 以内，内存峰值降低 18%。")
            appendLine("3. 交付节点：11 月中旬完成全量机型公测推送。")
        }.trim()
    }

    suspend fun parseExternalWebOrVideoUrl(url: String): String {
        delay(400)
        val isVideo = url.contains("bilibili", ignoreCase = true) ||
            url.contains("youtube", ignoreCase = true) ||
            url.contains("video", ignoreCase = true) ||
            url.contains("douyin", ignoreCase = true)

        return if (isVideo) {
            buildString {
                appendLine("【视频链接智能解析】来源：$url")
                appendLine("• 视频标题：ColorOS 17 流体云与端侧 AI 架构深度解析")
                appendLine("• 自动提取时间轴字幕：")
                appendLine("  [00:15] 介绍全新光锥毛玻璃渲染管线与高斯模糊实时混合；")
                appendLine("  [02:40] 演示浮动药丸导航栏的弹簧物理阻尼动效；")
                appendLine("  [05:10] 详解大文件无损流式导入与分段层级合并摘要。")
                appendLine("• 关键信息提炼：支持离线语音转写、说话人区分及一键生成结构化速览卡片。")
            }.trim()
        } else {
            buildString {
                appendLine("【网页正文智能抓取】来源：$url")
                appendLine("• 文章标题：现代移动端大文档流式处理与多模态笔记架构实践")
                appendLine("• 正文结构化提取：")
                appendLine("  1. 传统笔记应用因一次性加载内存常设 maxFileSize 阈值，极易导致大文档导入失败；")
                appendLine("  2. 通过 Kotlin Flow + 缓冲流分块读取，可实现任意体积 PDF/Word/Markdown 零OOM解析；")
                appendLine("  3. 配合层级树状合并（Hierarchical Map-Reduce），彻底告别文本截断。")
            }.trim()
        }
    }

    suspend fun organizeIntoStructuredNote(
        rawTitle: String,
        rawContent: String,
        fullSummary: String
    ): StructuredNoteResult {
        delay(250)
        val lines = rawContent.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val bullets = if (lines.isEmpty()) {
            listOf("已自动梳理核心议题与待办事项")
        } else {
            lines.mapIndexed { idx, line -> "要点 ${idx + 1}：$line" }
        }

        val summaryTable = StructuredTable(
            title = "AI 结构化整理矩阵",
            headers = listOf("维度", "提取内容", "状态/优先级"),
            rows = listOf(
                listOf("核心主题", rawTitle.ifBlank { "未命名多模态笔记" }, "高优 P0"),
                listOf("多模态来源", "文本 / 离线录音转写 / 文档流式解析", "已同步"),
                listOf("全文字符规模", "${rawContent.length} 字符（无损全覆盖）", "100% 已索引"),
                listOf("AI 行动建议", "生成速览卡片并归档至灵光一刻", "待执行")
            )
        )

        val htmlCard = buildAdaptiveHtmlQuickLookCard(
            title = rawTitle.ifBlank { "ColorOS 17 结构化笔记速览" },
            bullets = bullets,
            table = summaryTable,
            fullSummary = fullSummary
        )

        return StructuredNoteResult(
            refinedTitle = if (rawTitle.startsWith("【AI 整理】")) rawTitle else "【AI 整理】$rawTitle",
            bulletPoints = bullets,
            tables = listOf(summaryTable),
            fullHierarchicalSummary = fullSummary,
            htmlPreviewCard = htmlCard
        )
    }

    fun buildAdaptiveHtmlQuickLookCard(
        title: String,
        bullets: List<String>,
        table: StructuredTable,
        fullSummary: String
    ): String {
        val bulletItemsHtml = bullets.joinToString("") {
            "<li>${escapeHtml(it)}</li>"
        }
        val tableHeadersHtml = table.headers.joinToString("") {
            "<th>${escapeHtml(it)}</th>"
        }
        val tableRowsHtml = table.rows.joinToString("") { row ->
            "<tr>" + row.joinToString("") { cell -> "<td>${escapeHtml(cell)}</td>" } + "</tr>"
        }

        return buildString {
            appendLine("<!DOCTYPE html>")
            appendLine("<html lang=\"zh-CN\">")
            appendLine("<head>")
            appendLine("<meta charset=\"UTF-8\" />")
            appendLine("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0\" />")
            appendLine("<style>")
            appendLine(":root { --bg-glass: rgba(255, 255, 255, 0.88); --accent: #2563EB; --accent-soft: #DBEAFE; --text-main: #0F172A; --text-sub: #475569; }")
            appendLine("* { box-sizing: border-box; margin: 0; padding: 0; }")
            appendLine("body { font-family: -apple-system, BlinkMacSystemFont, sans-serif; background: linear-gradient(135deg, #EEF2FF 0%, #E0F2FE 55%, #F0FDFA 100%); color: var(--text-main); padding: 14px; }")
            appendLine(".card { background: var(--bg-glass); border-radius: 22px; padding: 18px; border: 1px solid rgba(255, 255, 255, 0.9); box-shadow: 0 10px 28px rgba(37, 99, 235, 0.10); }")
            appendLine(".badge { display: inline-block; font-size: 11px; font-weight: 600; color: var(--accent); background: var(--accent-soft); padding: 4px 10px; border-radius: 999px; margin-bottom: 10px; }")
            appendLine("h2 { font-size: 17px; line-height: 1.35; margin-bottom: 12px; }")
            appendLine(".summary-box { background: rgba(241, 245, 249, 0.85); border-left: 4px solid var(--accent); padding: 10px 12px; border-radius: 10px; font-size: 12px; color: var(--text-sub); white-space: pre-wrap; margin-bottom: 14px; }")
            appendLine("table { width: 100%; border-collapse: collapse; margin-bottom: 14px; font-size: 12px; }")
            appendLine("th, td { border: 1px solid #CBD5E1; padding: 7px 8px; text-align: left; }")
            appendLine("th { background: #EFF6FF; color: #1E3A8A; font-weight: 600; }")
            appendLine("ul { padding-left: 18px; font-size: 12px; color: var(--text-main); }")
            appendLine("li { margin-bottom: 6px; line-height: 1.45; }")
            appendLine("</style>")
            appendLine("</head>")
            appendLine("<body>")
            appendLine("<div class=\"card\">")
            appendLine("<span class=\"badge\">ColorOS 17 结构化速览图 · 自适应卡片</span>")
            appendLine("<h2>${escapeHtml(title)}</h2>")
            appendLine("<div class=\"summary-box\">${escapeHtml(fullSummary)}</div>")
            appendLine("<table><thead><tr>$tableHeadersHtml</tr></thead><tbody>$tableRowsHtml</tbody></table>")
            appendLine("<ul>$bulletItemsHtml</ul>")
            appendLine("</div>")
            appendLine("</body>")
            appendLine("</html>")
        }
    }

    fun scanNotesForSparkMoments(notes: List<NoteEntity>): List<SparkInsight> {
        return notes.mapIndexed { index, note ->
            val sentences = (note.structuredSummary + "\n" + note.rawContent)
                .split("。", "！", "？", "\n")
                .map { it.trim() }
                .filter { it.length >= 10 }

            val goldenQuote = sentences.firstOrNull()
                ?: "流式无损处理与流体交互，让每一次记录都成为灵感的起点。"

            SparkInsight(
                id = "spark_${note.id}_$index",
                sourceNoteId = note.id,
                sourceNoteTitle = note.title,
                goldenQuote = "“$goldenQuote”",
                keyInsight = "AI 洞察提炼：源自《${note.title}》，揭示了跨模态信息整合与高效知识沉淀的关键路径。",
                tags = listOf("#灵光一刻", "#${note.category}", "#AI深度提炼"),
                extractedAt = note.createdAt
            )
        }
    }

    suspend fun parseGlobalDragDropToNote(payload: DragDropPayload): NoteEntity {
        delay(220)
        var finalSummary = ""
        hierarchicalSummarizer.summarizeFullTextWithoutTruncation(payload.rawBody).collect { progress ->
            if (progress.finalSummary != null) {
                finalSummary = progress.finalSummary
            }
        }
        val structured = organizeIntoStructuredNote(
            rawTitle = "【智慧胶囊拖拽】${payload.rawTitle}",
            rawContent = payload.rawBody,
            fullSummary = finalSummary
        )
        return NoteEntity(
            id = "note_drag_${System.currentTimeMillis()}",
            title = structured.refinedTitle,
            rawContent = payload.rawBody,
            structuredSummary = structured.fullHierarchicalSummary,
            category = "全局拖拽 (${payload.payloadType})",
            createdAt = "刚刚 · 智慧胶囊解析",
            htmlVisualCard = structured.htmlPreviewCard
        )
    }

    suspend fun exportNoteToFormat(note: NoteEntity, format: ExportFormat): String {
        delay(200)
        return when (format) {
            ExportFormat.PDF -> "已通过流式分页引擎导出 PDF：/storage/emulated/0/Documents/ColorOS17Notes/${note.id}.pdf"
            ExportFormat.WORD -> "已通过 OpenXML 流式构建导出 Word：/storage/emulated/0/Documents/ColorOS17Notes/${note.id}.docx"
            ExportFormat.TXT -> "已通过 UTF-8 缓冲字符流导出纯文本：/storage/emulated/0/Documents/ColorOS17Notes/${note.id}.txt"
            ExportFormat.IMAGE -> "已渲染高清毛玻璃长图卡片：/storage/emulated/0/Pictures/ColorOS17Notes/${note.id}.png"
        }
    }

    private fun escapeHtml(input: String): String {
        return input
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
    }
}
