package io.fluid.ainotes.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import io.fluid.ainotes.data.model.DocumentFormat
import io.fluid.ainotes.data.model.DragDropPayload
import io.fluid.ainotes.data.model.ExportFormat
import io.fluid.ainotes.data.model.NoteEntity
import io.fluid.ainotes.data.model.SpeakerSegment
import io.fluid.ainotes.data.model.SparkInsight
import io.fluid.ainotes.data.model.StreamChunkProgress
import io.fluid.ainotes.data.model.StructuredNoteResult
import io.fluid.ainotes.data.model.SummarizationProgress
import io.fluid.ainotes.domain.HierarchicalSummarizer
import io.fluid.ainotes.domain.MultimodalAndExportEngines
import io.fluid.ainotes.domain.StreamingFileEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.nio.charset.StandardCharsets

data class AINotesUiState(
    val notes: List<NoteEntity> = emptyList(),
    val selectedNote: NoteEntity? = null,
    val streamProgress: StreamChunkProgress? = null,
    val isStreamingFile: Boolean = false,
    val summarizationProgress: SummarizationProgress? = null,
    val isSummarizing: Boolean = false,
    val speakerSegments: List<SpeakerSegment> = emptyList(),
    val isRecordingAudio: Boolean = false,
    val latestStructuredResult: StructuredNoteResult? = null,
    val sparkInsights: List<SparkInsight> = emptyList(),
    val statusBannerMessage: String = "ColorOS 17 流体引擎已就绪 · 支持无限大小流式导入与全量层级总结",
    val lastExportPath: String = ""
)

class MainViewModel : ViewModel() {

    private val streamingFileEngine = StreamingFileEngine()
    private val hierarchicalSummarizer = HierarchicalSummarizer()
    private val multimodalEngine = MultimodalAndExportEngines(hierarchicalSummarizer)

    private val _uiState = MutableStateFlow(AINotesUiState())
    val uiState: StateFlow<AINotesUiState> = _uiState.asStateFlow()

    init {
        seedInitialColorOS17Notes()
    }

    private fun seedInitialColorOS17Notes() {
        val sampleHtml = multimodalEngine.buildAdaptiveHtmlQuickLookCard(
            title = "ColorOS 17 端侧大模型与流体笔记架构",
            bullets = listOf(
                "要点 1：流式分块读取（Kotlin Flow + 缓冲流），彻底移除 maxFileSize 文件体积限制",
                "要点 2：分段总结 + 滚动上下文 + 树状层级合并，确保任意长度文本 100% 覆盖无截断",
                "要点 3：支持离线语音转写、说话人区分、PDF/Word/Markdown 导入及全局智慧胶囊拖拽"
            ),
            table = io.fluid.ainotes.data.model.StructuredTable(
                title = "核心能力对标表",
                headers = listOf("模块", "技术实现", "达标状态"),
                rows = listOf(
                    listOf("大文件流式导入", "InputStream 8KB 分块 Flow", "无体积上限"),
                    listOf("超长文本总结", "多层级滚动 Map-Reduce", "零 slice 截断"),
                    listOf("流体药丸导航", "Compose Spring 物理动效", "60/120Hz 自适应")
                )
            ),
            fullSummary = "【ColorOS 17 AI 全文无损层级总结】本笔记涵盖多模态录入、无限体积文档流式解析、层级滚动摘要与 HTML 速览图。"
        )

        val initialNotes = listOf(
            NoteEntity(
                id = "note_101",
                title = "ColorOS 17 端侧大模型与流体笔记架构",
                rawContent = "ColorOS 17 AI 笔记不仅追求毛玻璃与流体光锥动效，更在底层采用无上限流式文件读取与层级滚动合并摘要算法。无论是几百兆的学术 PDF、长篇 Word 报告还是万字 Markdown 笔记，都能边流式读取边实时反馈进度，并且通过分段总结、滚动汇总、层级合并生成覆盖全文的结构化笔记。",
                structuredSummary = "【ColorOS 17 AI 全文无损层级总结】底层采用流式分块读取与多层级滚动合并摘要，支持任意大小文件与任意长度文本。",
                category = "多模态记录",
                createdAt = "今天 09:30",
                htmlVisualCard = sampleHtml
            ),
            NoteEntity(
                id = "note_102",
                title = "产品周会：智慧胶囊全局拖拽与灵光一刻设计",
                rawContent = "用户在任意界面长按选中文字、图片、表格或文档并拖入顶部智慧胶囊后，系统自动唤起 AI 笔记解析引擎。同时灵光一刻页面会在空闲时自动扫描历史笔记，提炼金句与关键洞察卡片。",
                structuredSummary = "【ColorOS 17 AI 全文无损层级总结】打通全局智慧胶囊拖拽解析与历史笔记金句自动提炼闭环。",
                category = "全局拖拽",
                createdAt = "昨天 18:15",
                htmlVisualCard = sampleHtml
            )
        )

        _uiState.update {
            it.copy(
                notes = initialNotes,
                selectedNote = initialNotes.first(),
                sparkInsights = multimodalEngine.scanNotesForSparkMoments(initialNotes)
            )
        }
    }

    fun selectNote(note: NoteEntity) {
        _uiState.update { it.copy(selectedNote = note) }
    }

    /**
     * Unlimited size streaming file import (supports real URI InputStream or simulated multi-chunk stream).
     * Strictly no maxFileSize limit.
     */
    fun importStreamedDocument(
        fileName: String,
        format: DocumentFormat,
        inputStreamProvider: () -> InputStream,
        estimatedBytes: Long = -1L
    ) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isStreamingFile = true,
                    statusBannerMessage = "正在流式分块读取 $fileName（无文件大小限制）..."
                )
            }

            val accumulatedBuilder = StringBuilder()
            streamingFileEngine.streamAndParseDocument(
                inputStreamProvider = inputStreamProvider,
                format = format,
                estimatedTotalBytes = estimatedBytes
            ).collect { progress ->
                if (progress.latestChunkText.isNotEmpty()) {
                    if (accumulatedBuilder.isNotEmpty()) accumulatedBuilder.append("\n")
                    accumulatedBuilder.append(progress.latestChunkText)
                }
                _uiState.update { state ->
                    state.copy(
                        streamProgress = progress,
                        statusBannerMessage = if (!progress.isComplete) {
                            "流式读取中：已处理第 ${progress.chunkIndex} 块 (${progress.bytesProcessedSoFar} Bytes)"
                        } else {
                            "流式读取完成：共 ${progress.chunkIndex} 个分块，启动全文无损层级总结..."
                        }
                    )
                }
            }

            _uiState.update { it.copy(isStreamingFile = false) }
            val fullImportedText = accumulatedBuilder.toString()
            createNoteWithUnlimitedHierarchicalSummary(
                title = "【文档导入】$fileName",
                rawContent = fullImportedText,
                category = "文档导入 (${format.name})"
            )
        }
    }

    /**
     * Helper to simulate a large multi-chunk document import (PDF / DOCX / MD) without external storage dependency.
     */
    fun simulateLargeDocumentStreamingImport(format: DocumentFormat) {
        val sampleFileName = when (format) {
            DocumentFormat.PDF -> "ColorOS17_Architecture_Whitepaper_Large.pdf"
            DocumentFormat.DOCX -> "Global_Product_Requirement_Spec_Full.docx"
            DocumentFormat.MARKDOWN -> "Deep_Learning_Note_Archive_Complete.md"
            DocumentFormat.UNKNOWN -> "Unbounded_Stream_Data.txt"
        }

        val largeSyntheticText = buildString {
            for (section in 1..18) {
                appendLine("## 第 $section 章节：流式分块与全量层级摘要架构详述")
                appendLine("本章节详细阐述了在移动端处理超大规模文档（第 $section 部分）时，如何通过 BufferedReader 与 Kotlin Flow 避免一次性内存分配。")
                appendLine("同时，在文本总结阶段，严禁使用 slice(0, N) 截断文本，必须将第 $section 章节的每一个自然段纳入分段总结、滚动上下文传递与多层级树状合并计算中。")
                appendLine("关键结论 $section：端云协同与流体交互确保了极致的响应速度与 100% 的全文信息保留率。")
                appendLine()
            }
        }
        val bytes = largeSyntheticText.toByteArray(StandardCharsets.UTF_8)
        importStreamedDocument(
            fileName = sampleFileName,
            format = format,
            inputStreamProvider = { ByteArrayInputStream(bytes) },
            estimatedBytes = bytes.size.toLong()
        )
    }

    /**
     * Unlimited length text summarization using Segmented -> Rolling -> Hierarchical Merge.
     */
    fun createNoteWithUnlimitedHierarchicalSummary(
        title: String,
        rawContent: String,
        category: String,
        sourceUrl: String = ""
    ) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isSummarizing = true,
                    statusBannerMessage = "正在执行分段总结 → 滚动汇总 → 层级合并（全文零截断）..."
                )
            }

            var finalMergedSummary = ""
            hierarchicalSummarizer.summarizeFullTextWithoutTruncation(rawContent).collect { sumProgress ->
                _uiState.update { state ->
                    state.copy(
                        summarizationProgress = sumProgress,
                        statusBannerMessage = "第 ${sumProgress.currentLevel} 层级合并中 (${sumProgress.processedChunksInLevel}/${sumProgress.totalChunksInLevel})"
                    )
                }
                if (sumProgress.finalSummary != null) {
                    finalMergedSummary = sumProgress.finalSummary
                }
            }

            val structuredResult = multimodalEngine.organizeIntoStructuredNote(
                rawTitle = title,
                rawContent = rawContent,
                fullSummary = finalMergedSummary
            )

            val newNote = NoteEntity(
                id = "note_${System.currentTimeMillis()}",
                title = structuredResult.refinedTitle,
                rawContent = rawContent,
                structuredSummary = finalMergedSummary,
                category = category,
                createdAt = "刚刚",
                sourceUrl = sourceUrl,
                htmlVisualCard = structuredResult.htmlPreviewCard
            )

            _uiState.update { state ->
                val updatedList = listOf(newNote) + state.notes
                state.copy(
                    isSummarizing = false,
                    notes = updatedList,
                    selectedNote = newNote,
                    latestStructuredResult = structuredResult,
                    sparkInsights = multimodalEngine.scanNotesForSparkMoments(updatedList),
                    statusBannerMessage = "笔记已生成：全文共 ${rawContent.length} 字完成无损层级汇总与速览卡片渲染"
                )
            }
        }
    }

    fun triggerOfflineVoiceRecordingAndDiarization() {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isRecordingAudio = true,
                    statusBannerMessage = "正在进行离线端侧语音转写与多说话人声纹分离..."
                )
            }
            val segments = multimodalEngine.runOfflineVoiceTranscriptionWithDiarization(durationSeconds = 68)
            val combinedTranscript = segments.joinToString("\n") {
                "[${it.timestampRange}] ${it.speakerName}：${it.transcript}"
            }
            _uiState.update { it.copy(isRecordingAudio = false, speakerSegments = segments) }

            createNoteWithUnlimitedHierarchicalSummary(
                title = "离线录音转写（含说话人识别）",
                rawContent = combinedTranscript,
                category = "多模态记录"
            )
        }
    }

    fun triggerCameraScanOcr() {
        viewModelScope.launch {
            _uiState.update { it.copy(statusBannerMessage = "正在启动超清文档曲面矫正与离线 OCR 识别...") }
            val ocrText = multimodalEngine.performCameraDocumentOcrScan("白板架构草图与会议纪要")
            createNoteWithUnlimitedHierarchicalSummary(
                title = "拍照扫描文档 OCR",
                rawContent = ocrText,
                category = "多模态记录"
            )
        }
    }

    fun parseExternalLinkAndCreateNote(url: String) {
        viewModelScope.launch {
            val cleanUrl = url.ifBlank { "https://open.oppomobile.com/coloros17/ai-notes-tech-blog" }
            _uiState.update { it.copy(statusBannerMessage = "正在抓取外部链接正文/视频字幕：$cleanUrl") }
            val extractedContent = multimodalEngine.parseExternalWebOrVideoUrl(cleanUrl)
            createNoteWithUnlimitedHierarchicalSummary(
                title = "外链解析：${cleanUrl.substringAfterLast("/")}",
                rawContent = extractedContent,
                category = "外链解析",
                sourceUrl = cleanUrl
            )
        }
    }

    fun handleGlobalSmartCapsuleDrop(payload: DragDropPayload) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(statusBannerMessage = "智慧胶囊已接收拖拽内容 [${payload.payloadType}]，正在由 AI 解析生成结构化笔记...")
            }
            val droppedNote = multimodalEngine.parseGlobalDragDropToNote(payload)
            _uiState.update { state ->
                val updated = listOf(droppedNote) + state.notes
                state.copy(
                    notes = updated,
                    selectedNote = droppedNote,
                    sparkInsights = multimodalEngine.scanNotesForSparkMoments(updated),
                    statusBannerMessage = "智慧胶囊解析完成：《${droppedNote.title}》已归档"
                )
            }
        }
    }

    fun exportSelectedNote(format: ExportFormat) {
        val current = _uiState.value.selectedNote ?: return
        viewModelScope.launch {
            val path = multimodalEngine.exportNoteToFormat(current, format)
            _uiState.update {
                it.copy(
                    lastExportPath = path,
                    statusBannerMessage = path
                )
            }
        }
    }
}
