package io.fluid.ainotes.ui.screens

import android.webkit.WebView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddLink
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PanToolAlt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import io.fluid.ainotes.data.model.DocumentFormat
import io.fluid.ainotes.data.model.DragDropPayload
import io.fluid.ainotes.data.model.ExportFormat
import io.fluid.ainotes.ui.AINotesUiState
import io.fluid.ainotes.ui.MainViewModel
import io.fluid.ainotes.ui.components.FluidPillNavigationBar
import io.fluid.ainotes.ui.components.NavTab
import io.fluid.ainotes.ui.theme.ColorOSDeepInk
import io.fluid.ainotes.ui.theme.ColorOSFluidBlue
import io.fluid.ainotes.ui.theme.ColorOSFluidCyan
import io.fluid.ainotes.ui.theme.ColorOSFluidMint
import io.fluid.ainotes.ui.theme.ColorOSFluidViolet
import io.fluid.ainotes.ui.theme.ColorOSSubtleSlate
import io.fluid.ainotes.ui.theme.colorOSGlassCard
import java.io.ByteArrayInputStream

@Composable
fun ColorOS17NotesApp(viewModel: MainViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableStateOf(NavTab.NOTES) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFE0E7FF),
                        Color(0xFFE0F2FE),
                        Color(0xFFF0FDFA),
                        Color(0xFFF8FAFC)
                    )
                )
            )
    ) {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                SmartCapsuleHeader(
                    statusMessage = uiState.statusBannerMessage,
                    onDropSample = { payload ->
                        viewModel.handleGlobalSmartCapsuleDrop(payload)
                    }
                )
            },
            bottomBar = {
                FluidPillNavigationBar(
                    selectedTab = selectedTab,
                    onTabSelected = { selectedTab = it }
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (selectedTab) {
                    NavTab.NOTES -> NotesWorkspaceScreen(uiState = uiState, viewModel = viewModel)
                    NavTab.MULTIMODAL -> MultimodalAndStreamingImportScreen(uiState = uiState, viewModel = viewModel)
                    NavTab.AI_STUDIO -> AIStructuredQuickLookScreen(uiState = uiState, viewModel = viewModel)
                    NavTab.SPARK_MOMENT -> SparkMomentScreen(uiState = uiState)
                }
            }
        }
    }
}

/**
 * Top Global Drag-and-Drop Smart Capsule ("智慧胶囊") + Real-time Fluid Status Bar.
 */
@Composable
fun SmartCapsuleHeader(
    statusMessage: String,
    onDropSample: (DragDropPayload) -> Unit
) {
    var showCapsuleTray by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // ColorOS 17 Fluid Cloud Smart Capsule
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xFF0F172A),
                            Color(0xFF1E3A8A),
                            Color(0xFF0F172A)
                        )
                    )
                )
                .border(1.dp, Color.White.copy(alpha = 0.28f), RoundedCornerShape(28.dp))
                .clickable { showCapsuleTray = !showCapsuleTray }
                .padding(horizontal = 16.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(ColorOSFluidMint)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "ColorOS 17 智慧胶囊 · 全局拖拽解析区",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = statusMessage,
                        color = Color(0xFFBAE6FD),
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.16f))
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.PanToolAlt,
                    contentDescription = "全局拖拽",
                    tint = Color.White,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (showCapsuleTray) "收起拖拽源" else "拖入胶囊",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        AnimatedVisibility(visible = showCapsuleTray, enter = fadeIn(), exit = fadeOut()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
                    .colorOSGlassCard(cornerRadius = 20.dp)
                    .padding(12.dp)
            ) {
                Text(
                    text = "模拟从其他应用长按拖入智慧胶囊（文字 / 图片 / 表格 / 文档）：",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = ColorOSDeepInk
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val dragPresets = listOf(
                        DragDropPayload(
                            id = "d_text",
                            payloadType = "文字段落",
                            rawTitle = "跨应用拖拽长文选段",
                            rawBody = "从浏览器拖拽的行业深度分析：端侧大模型与流式笔记结合后，用户可直接将任意网页长文拖入顶部流体云智慧胶囊，系统自动进行分段总结与无损层级合并。"
                        ),
                        DragDropPayload(
                            id = "d_table",
                            payloadType = "数据表格",
                            rawTitle = "Q4 研发里程碑表格",
                            rawBody = "模块：流式文件引擎 | 指标：无文件大小限制 | 状态：已完成\n模块：层级合并总结 | 指标：0% 文本截断 | 状态：已验证"
                        ),
                        DragDropPayload(
                            id = "d_doc",
                            payloadType = "混排文档",
                            rawTitle = "图文混排会议纪要.docx",
                            rawBody = "拖拽自文件管理器的完整项目纪要：包含离线语音转写说话人分离记录、拍照白板 OCR 文本及 HTML 速览图生成规范。"
                        )
                    )
                    dragPresets.forEach { preset ->
                        OutlinedButton(
                            onClick = {
                                onDropSample(preset)
                                showCapsuleTray = false
                            },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)
                        ) {
                            Text(text = "拖入${preset.payloadType}", fontSize = 11.sp, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NotesWorkspaceScreen(
    uiState: AINotesUiState,
    viewModel: MainViewModel
) {
    var quickNoteTitle by remember { mutableStateOf("") }
    var quickNoteBody by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Unlimited length note creation card
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .colorOSGlassCard(cornerRadius = 24.dp)
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = ColorOSFluidBlue
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "新建无上限流式笔记（全文层级合并总结 · 零截断）",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = ColorOSDeepInk
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = quickNoteTitle,
                    onValueChange = { quickNoteTitle = it },
                    label = { Text("笔记标题") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = quickNoteBody,
                    onValueChange = { quickNoteBody = it },
                    label = { Text("输入任意长度正文（不限字数，自动分段→滚动汇总→层级合并）") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 96.dp, max = 180.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))

                if (uiState.isSummarizing && uiState.summarizationProgress != null) {
                    val p = uiState.summarizationProgress
                    LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "正在执行第 ${p.currentLevel} 层级合并 (${p.processedChunksInLevel}/${p.totalChunksInLevel})",
                        fontSize = 11.sp,
                        color = ColorOSFluidBlue
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            val titleToUse = quickNoteTitle.ifBlank { "未命名长文笔记" }
                            val bodyToUse = quickNoteBody.ifBlank {
                                "这是通过 ColorOS 17 AI 笔记创建的示例长文。系统采用分段总结、滚动上下文汇总与多层级树状合并算法，绝不使用 slice(0, N) 截断任何段落，确保全文每一个要点都被精准涵盖。"
                            }
                            viewModel.createNoteWithUnlimitedHierarchicalSummary(
                                title = titleToUse,
                                rawContent = bodyToUse,
                                category = "多模态记录"
                            )
                            quickNoteTitle = ""
                            quickNoteBody = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ColorOSFluidBlue),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("AI 全量总结并保存", fontSize = 13.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            // Generate a 10,000+ character stress test text to prove zero truncation
                            val stressText = buildString {
                                for (i in 1..45) {
                                    append("【第 $i 自然段】在超长文档总结测试中，传统截断方式会丢失后半部分关键结论，而本工程采用多层级滚动归并树，完整保留第 $i 段的核心数据与逻辑链路。")
                                }
                            }
                            viewModel.createNoteWithUnlimitedHierarchicalSummary(
                                title = "万字长文无截断压力测试笔记",
                                rawContent = stressText,
                                category = "多模态记录"
                            )
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("生成长文无截断实测", fontSize = 13.sp)
                    }
                }
            }
        }

        // Multi-format Export Bar for Selected Note
        uiState.selectedNote?.let { selected ->
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .colorOSGlassCard(cornerRadius = 20.dp)
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "当前选中：《${selected.title}》 · 多格式导出",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = ColorOSDeepInk,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = null,
                            tint = ColorOSFluidBlue,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ExportFormat.entries.forEach { format ->
                            OutlinedButton(
                                onClick = { viewModel.exportSelectedNote(format) },
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(text = "导出 ${format.extension.uppercase()}", fontSize = 12.sp)
                            }
                        }
                    }
                    if (uiState.lastExportPath.isNotBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = uiState.lastExportPath,
                            fontSize = 11.sp,
                            color = ColorOSFluidMint,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Notes List
        items(uiState.notes, key = { it.id }) { note ->
            val isSelected = uiState.selectedNote?.id == note.id
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .colorOSGlassCard(cornerRadius = 22.dp)
                    .border(
                        width = if (isSelected) 2.dp else 0.dp,
                        color = if (isSelected) ColorOSFluidBlue else Color.Transparent,
                        shape = RoundedCornerShape(22.dp)
                    )
                    .clickable { viewModel.selectNote(note) }
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = note.category,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = ColorOSFluidBlue,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(ColorOSFluidBlue.copy(alpha = 0.12f))
                            .padding(horizontal = 10.dp, vertical = 3.dp)
                    )
                    Text(
                        text = "${note.createdAt} · 全文 ${note.rawContent.length} 字",
                        fontSize = 11.sp,
                        color = ColorOSSubtleSlate
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = note.title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = ColorOSDeepInk
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = note.structuredSummary,
                    fontSize = 13.sp,
                    color = ColorOSDeepInk.copy(alpha = 0.85f),
                    lineHeight = 19.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = Color.LightGray.copy(alpha = 0.4f))
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "原文预览：${note.rawContent}",
                    fontSize = 12.sp,
                    color = ColorOSSubtleSlate,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

/**
 * Screen 2: Multimodal Recording + Unlimited Size File Streaming Import + External URL Parser
 */
@Composable
fun MultimodalAndStreamingImportScreen(
    uiState: AINotesUiState,
    viewModel: MainViewModel
) {
    val context = LocalContext.current
    var externalUrl by remember { mutableStateOf("https://www.bilibili.com/video/BV1ColorOS17AINotes") }

    // System SAF file picker supporting arbitrary size PDF, DOCX, Markdown files via ContentResolver InputStream
    val safPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val pathOrLast = uri.lastPathSegment ?: "Picked_Document"
            val detectedFormat = when {
                pathOrLast.endsWith(".pdf", true) -> DocumentFormat.PDF
                pathOrLast.endsWith(".docx", true) -> DocumentFormat.DOCX
                pathOrLast.endsWith(".md", true) -> DocumentFormat.MARKDOWN
                else -> DocumentFormat.MARKDOWN
            }
            viewModel.importStreamedDocument(
                fileName = pathOrLast,
                format = detectedFormat,
                inputStreamProvider = {
                    context.contentResolver.openInputStream(uri)
                        ?: ByteArrayInputStream("流式读取回退内容".toByteArray())
                }
            )
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Section A: Multimodal Voice (Offline Transcription + Diarization) & Camera Scan
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .colorOSGlassCard(cornerRadius = 24.dp)
                    .padding(16.dp)
            ) {
                Text(
                    text = "1. 多模态记录（离线语音声纹转写 / 拍照扫描 OCR）",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = ColorOSDeepInk
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { viewModel.triggerOfflineVoiceRecordingAndDiarization() },
                        colors = ButtonDefaults.buttonColors(containerColor = ColorOSFluidBlue),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("录音+说话人识别", fontSize = 12.sp)
                    }
                    Button(
                        onClick = { viewModel.triggerCameraScanOcr() },
                        colors = ButtonDefaults.buttonColors(containerColor = ColorOSFluidCyan),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("拍照文档扫描", fontSize = 12.sp)
                    }
                }

                if (uiState.speakerSegments.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "最近一次离线录音分角色转写明细：",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = ColorOSFluidBlue
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    uiState.speakerSegments.forEach { seg ->
                        Text(
                            text = "[${seg.timestampRange}] ${seg.speakerName}：${seg.transcript}",
                            fontSize = 12.sp,
                            color = ColorOSDeepInk,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }

        // Section B: Unlimited File Size Streaming Import (PDF / Word .docx / Markdown .md)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .colorOSGlassCard(cornerRadius = 24.dp)
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CloudUpload, contentDescription = null, tint = ColorOSFluidViolet)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "2. 无大小限制流式文件导入（PDF / Word .docx / Markdown .md）",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = ColorOSDeepInk
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "采用 InputStream + Kotlin Flow 8KB 分块流式读取，无 maxFileSize 限制，实时反馈分块进度：",
                    fontSize = 12.sp,
                    color = ColorOSSubtleSlate
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.simulateLargeDocumentStreamingImport(DocumentFormat.PDF) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("流式导入 PDF", fontSize = 12.sp)
                    }
                    OutlinedButton(
                        onClick = { viewModel.simulateLargeDocumentStreamingImport(DocumentFormat.DOCX) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("流式导入 DOCX", fontSize = 12.sp)
                    }
                    OutlinedButton(
                        onClick = { viewModel.simulateLargeDocumentStreamingImport(DocumentFormat.MARKDOWN) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("流式导入 MD", fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = {
                        safPickerLauncher.launch(
                            arrayOf(
                                "application/pdf",
                                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                "text/markdown",
                                "text/plain"
                            )
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ColorOSFluidViolet),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.FileOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("从系统文件选择器流式导入本地超大文件 (SAF)", fontSize = 13.sp)
                }

                uiState.streamProgress?.let { prog ->
                    Spacer(modifier = Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = { if (prog.totalBytesEstimated > 0) prog.progressFraction else 1f },
                        modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "流式分块 #${prog.chunkIndex} · 已读取 ${prog.bytesProcessedSoFar} Bytes · 状态：${if (prog.isComplete) "已完成" else "流式读取中"}",
                        fontSize = 11.sp,
                        color = ColorOSFluidViolet,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Section C: External Web / Video Link Parsing
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .colorOSGlassCard(cornerRadius = 24.dp)
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AddLink, contentDescription = null, tint = ColorOSFluidBlue)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "3. 外部网页 / 视频链接导入与解析",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = ColorOSDeepInk
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = externalUrl,
                    onValueChange = { externalUrl = it },
                    label = { Text("粘贴网页或视频链接（自动提取正文、时间轴字幕与关键信息）") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = { viewModel.parseExternalLinkAndCreateNote(externalUrl) },
                    colors = ButtonDefaults.buttonColors(containerColor = ColorOSFluidBlue),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("一键抓取正文/字幕并生成结构化笔记", fontSize = 13.sp)
                }
            }
        }
    }
}

/**
 * Screen 3: AI Note Assistant (Rich-text Tables & Lists) + Adaptive HTML Quick-Look Card Preview
 */
@Composable
fun AIStructuredQuickLookScreen(
    uiState: AINotesUiState,
    viewModel: MainViewModel
) {
    val activeNote = uiState.selectedNote ?: uiState.notes.firstOrNull()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .colorOSGlassCard(cornerRadius = 24.dp)
                    .padding(16.dp)
            ) {
                Text(
                    text = "AI 笔记助手 · 富文本结构化表格与列表",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = ColorOSDeepInk
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "当前展示笔记：《${activeNote?.title ?: "暂无"}》",
                    fontSize = 13.sp,
                    color = ColorOSFluidBlue,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = activeNote?.structuredSummary ?: "",
                    fontSize = 13.sp,
                    color = ColorOSDeepInk
                )
            }
        }

        // In-page Adaptive WebView HTML Visualization Card
        if (activeNote != null && activeNote.htmlVisualCard.isNotBlank()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .colorOSGlassCard(cornerRadius = 24.dp)
                        .padding(14.dp)
                ) {
                    Text(
                        text = "结构化速览图（页面内自适应 HTML 可视化卡片预览）",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = ColorOSDeepInk
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(370.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .border(1.dp, Color.White, RoundedCornerShape(18.dp))
                    ) {
                        AndroidView(
                            modifier = Modifier.fillMaxSize(),
                            factory = { ctx ->
                                WebView(ctx).apply {
                                    settings.javaScriptEnabled = false
                                    settings.loadWithOverviewMode = true
                                    settings.useWideViewPort = true
                                    setBackgroundColor(android.graphics.Color.TRANSPARENT)
                                }
                            },
                            update = { webView ->
                                webView.loadDataWithBaseURL(
                                    null,
                                    activeNote.htmlVisualCard,
                                    "text/html",
                                    "UTF-8",
                                    null
                                )
                            }
                        )
                    }
                }
            }
        }
    }
}

/**
 * Screen 4: Spark Moment ("灵光一刻" dedicated page scanning historical notes for golden quotes & insights)
 */
@Composable
fun SparkMomentScreen(uiState: AINotesUiState) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .colorOSGlassCard(cornerRadius = 24.dp)
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.ElectricBolt,
                        contentDescription = null,
                        tint = ColorOSFluidViolet
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "灵光一刻 · 历史笔记金句与关键洞察自动提炼",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = ColorOSDeepInk
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "系统已自动扫描全部 ${uiState.notes.size} 篇历史笔记，提炼出 ${uiState.sparkInsights.size} 张灵感洞察卡：",
                    fontSize = 12.sp,
                    color = ColorOSSubtleSlate
                )
            }
        }

        items(uiState.sparkInsights, key = { it.id }) { spark ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .colorOSGlassCard(cornerRadius = 22.dp)
                    .padding(16.dp)
            ) {
                Text(
                    text = spark.goldenQuote,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = ColorOSFluidViolet,
                    lineHeight = 22.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = spark.keyInsight,
                    fontSize = 13.sp,
                    color = ColorOSDeepInk
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = spark.tags.joinToString("  "),
                        fontSize = 11.sp,
                        color = ColorOSFluidBlue,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "源自《${spark.sourceNoteTitle}》",
                        fontSize = 11.sp,
                        color = ColorOSSubtleSlate
                    )
                }
            }
        }
    }
}
