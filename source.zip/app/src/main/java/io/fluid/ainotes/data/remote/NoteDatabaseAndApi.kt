package io.fluid.ainotes.data.remote

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import io.fluid.ainotes.data.model.NoteEntity
import retrofit2.http.Body
import retrofit2.http.POST

/**
 * Room DAO interface reserved for local persistence of ColorOS 17 AI Notes.
 */
@Dao
interface NoteDao {
    @Query("SELECT * FROM ai_notes ORDER BY createdAt DESC")
    suspend fun getAllNotes(): List<NoteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertNote(note: NoteEntity)
}

data class CloudSummarizeRequest(
    val level: Int,
    val segmentIndex: Int,
    val segmentContent: String
)

data class CloudSummarizeResponse(
    val summarySegment: String,
    val keyEntities: List<String>
)

/**
 * Retrofit service interface reserved for ColorOS AndesGPT / Cloud AI Note endpoints.
 */
interface ColorOSAndesGptApi {
    @POST("v1/andesgpt/notes/segment-summarize")
    suspend fun summarizeSegment(@Body request: CloudSummarizeRequest): CloudSummarizeResponse
}
