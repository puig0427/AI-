package io.fluid.ainotes.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.fluid.ainotes.ui.theme.ColorOSDeepInk
import io.fluid.ainotes.ui.theme.ColorOSFluidBlue
import io.fluid.ainotes.ui.theme.ColorOSFluidCyan
import io.fluid.ainotes.ui.theme.ColorOSFluidViolet
import io.fluid.ainotes.ui.theme.ColorOSSubtleSlate

enum class NavTab(val title: String, val icon: ImageVector) {
    NOTES("全部笔记", Icons.Default.Description),
    MULTIMODAL("多模态与导入", Icons.Default.GraphicEq),
    AI_STUDIO("AI 速览图", Icons.Default.AutoAwesome),
    SPARK_MOMENT("灵光一刻", Icons.Default.ElectricBolt)
}

/**
 * ColorOS 17 signature Floating Pill Navigation Bar with Fluid Spring Animation
 * and Frosted Glassmorphism aesthetics.
 */
@Composable
fun FluidPillNavigationBar(
    selectedTab: NavTab,
    onTabSelected: (NavTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val tabs = NavTab.entries
    val selectedIndex = tabs.indexOf(selectedTab).coerceAtLeast(0)

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 12.dp)
            .height(66.dp)
            .shadow(
                elevation = 20.dp,
                shape = CircleShape,
                ambientColor = ColorOSFluidBlue.copy(alpha = 0.25f),
                spotColor = ColorOSFluidViolet.copy(alpha = 0.28f)
            )
            .clip(CircleShape)
            .background(
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.88f),
                        Color(0xFFF0F9FF).copy(alpha = 0.88f),
                        Color.White.copy(alpha = 0.88f)
                    )
                )
            )
            .border(
                width = 1.2.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White,
                        ColorOSFluidCyan.copy(alpha = 0.45f),
                        Color.White
                    )
                ),
                shape = CircleShape
            )
            .padding(6.dp)
    ) {
        val itemWidth = maxWidth / tabs.size

        // Fluid spring-animated pill indicator offset
        val indicatorOffset by animateDpAsState(
            targetValue = itemWidth * selectedIndex,
            animationSpec = spring(
                dampingRatio = 0.68f,
                stiffness = Spring.StiffnessMediumLow
            ),
            label = "FluidPillOffset"
        )

        // Active fluid pill background
        Box(
            modifier = Modifier
                .offset(x = indicatorOffset)
                .width(itemWidth)
                .fillMaxHeight()
                .clip(RoundedCornerShape(50))
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            ColorOSFluidBlue,
                            ColorOSFluidCyan
                        )
                    )
                )
        )

        Row(
            modifier = Modifier.fillMaxWidth().fillMaxHeight(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            tabs.forEach { tab ->
                val isSelected = tab == selectedTab
                val scale by animateFloatAsState(
                    targetValue = if (isSelected) 1.05f else 0.94f,
                    animationSpec = spring(dampingRatio = 0.65f, stiffness = Spring.StiffnessMedium),
                    label = "TabScale"
                )
                val contentColor by animateColorAsState(
                    targetValue = if (isSelected) Color.White else ColorOSSubtleSlate,
                    label = "TabColor"
                )

                Row(
                    modifier = Modifier
                        .width(itemWidth)
                        .fillMaxHeight()
                        .scale(scale)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onTabSelected(tab) },
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = tab.icon,
                        contentDescription = tab.title,
                        tint = contentColor,
                        modifier = Modifier.size(19.dp)
                    )
                    if (isSelected) {
                        Text(
                            text = tab.title,
                            color = contentColor,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            modifier = Modifier.padding(start = 5.dp)
                        )
                    } else {
                        Text(
                            text = tab.title.substring(0, 2),
                            color = ColorOSDeepInk.copy(alpha = 0.65f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            modifier = Modifier.padding(start = 3.dp)
                        )
                    }
                }
            }
        }
    }
}
