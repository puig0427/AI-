package io.fluid.ainotes.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class NoteCategory(val label: String) {
    ALL("全部笔记"),
    MULTIMODAL("多模态记录"),
    IMPORTED_DOC("文档导入"),
    WEB_LINK("外链解析"),
    DRAG_DROP("全局拖拽")
}

enum class ExportFormat(val extension: String, val mimeType: String, val displayName: String) {
    PDF("pdf", "application/pdf", "PDF 排版文档 (.pdf)"),
    WORD("docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "Word 文档 (.docx)"),
    TXT("txt", "text/plain", "纯文本文件 (.txt)"),
    IMAGE("png", "image/png", "长图海报 (.png)")
}

enum class DocumentFormat {
    PDF, DOCX, MARKDOWN, UNKNOWN
}

data class SpeakerSegment(
    val speakerId: String,
    val speakerName: String,
    val timestampRange: String,
    val transcript: String
)

data class StructuredTable(
    val title: String,
    val headers: List<String>,
    val rows: List<List<String>>
)

data class StructuredNoteResult(
    val refinedTitle: String,
    val bulletPoints: List<String>,
    val tables: List<StructuredTable>,
    val fullHierarchicalSummary: String,
    val htmlPreviewCard: String
)

data class SparkInsight(
    val id: String,
    val sourceNoteId: String,
    val sourceNoteTitle: String,
    val goldenQuote: String,
    val keyInsight: String,
    val tags: List<String>,
    val extractedAt: String
)

data class StreamChunkProgress(
    val chunkIndex: Int,
    val bytesProcessedSoFar: Long,
    val totalBytesEstimated: Long, // -1L if stream length is unknown; no upper bound
    val latestChunkText: String,
    val isComplete: Boolean = false
) {
    val progressFraction: Float
        get() = if (totalBytesEstimated > 0L) {
            (bytesProcessedSoFar.toFloat() / totalBytesEstimated.toFloat()).coerceIn(0f, 1f)
        } else {
            0f
        }
}

data class SummarizationProgress(
    val currentLevel: Int,
    val processedChunksInLevel: Int,
    val totalChunksInLevel: Int,
    val intermediateSummaryPreview: String,
    val finalSummary: String? = null
)

data class DragDropPayload(
    val id: String,
    val payloadType: String, // TEXT, IMAGE, TABLE, DOCUMENT
    val rawTitle: String,
    val rawBody: String
)

@Entity(tableName = "ai_notes")
data class NoteEntity(
    @PrimaryKey val id: String,
    val title: String,
    val rawContent: String,
    val structuredSummary: String,
    val category: String,
    val createdAt: String,
    val audioTranscriptSummary: String = "",
    val scannedOcrText: String = "",
    val sourceUrl: String = "",
    val htmlVisualCard: String = ""
)
