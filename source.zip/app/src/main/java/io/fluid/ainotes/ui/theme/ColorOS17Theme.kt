package io.fluid.ainotes.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

val ColorOSFluidBlue = Color(0xFF2563EB)
val ColorOSFluidCyan = Color(0xFF06B6D4)
val ColorOSFluidViolet = Color(0xFF7C3AED)
val ColorOSFluidMint = Color(0xFF10B981)
val ColorOSGlassWhite = Color(0xD9FFFFFF)
val ColorOSGlassBorder = Color(0xB3FFFFFF)
val ColorOSDeepInk = Color(0xFF0F172A)
val ColorOSSubtleSlate = Color(0xFF475569)

private val ColorOS17LightScheme = lightColorScheme(
    primary = ColorOSFluidBlue,
    secondary = ColorOSFluidCyan,
    tertiary = ColorOSFluidViolet,
    background = Color(0xFFF1F5F9),
    surface = Color(0xFFFFFFFF),
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = ColorOSDeepInk,
    onSurface = ColorOSDeepInk
)

@Composable
fun ColorOS17AINotesTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ColorOS17LightScheme,
        content = content
    )
}

/**
 * Reusable ColorOS 17 Acrylic / Frosted Glassmorphism surface modifier.
 */
fun Modifier.colorOSGlassCard(
    cornerRadius: Dp = 24.dp,
    alpha: Float = 0.82f
): Modifier {
    val shape = RoundedCornerShape(cornerRadius)
    return this
        .clip(shape)
        .background(
            brush = Brush.linearGradient(
                colors = listOf(
                    Color.White.copy(alpha = alpha),
                    Color(0xFFF8FAFC).copy(alpha = (alpha - 0.08f).coerceAtLeast(0.5f))
                )
            )
        )
        .border(
            width = 1.dp,
            brush = Brush.linearGradient(
                colors = listOf(
                    ColorOSGlassBorder,
                    Color(0x66CBD5E1)
                )
            ),
            shape = shape
        )
}
