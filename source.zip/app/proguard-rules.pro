# Add project specific ProGuard rules here.
-keep class io.fluid.ainotes.data.model.** { *; }
