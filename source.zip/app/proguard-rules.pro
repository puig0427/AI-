# Add project specific ProGuard rules here.
-keep class com.oppo.coloros17.ainotes.data.model.** { *; }
