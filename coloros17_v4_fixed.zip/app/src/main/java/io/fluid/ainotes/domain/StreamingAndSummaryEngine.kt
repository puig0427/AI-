package io.fluid.ainotes.domain

import io.fluid.ainotes.data.model.DocumentFormat
import io.fluid.ainotes.data.model.LlmApiConfig
import io.fluid.ainotes.data.model.StreamChunkProgress
import io.fluid.ainotes.data.model.SummarizationProgress
import io.fluid.ainotes.data.remote.LlmApiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets

/**
 * Implements Hard Requirement #1 (Unlimited File Size Streaming I/O without maxFileSize)
 * and Hard Requirement #2 (Unlimited Text Length Hierarchical Map-Reduce Summarization without slice truncation).
 */
class StreamingAndSummaryEngine(
    private val llmApiClient: LlmApiClient
) {

    companion object {
        private const val STREAM_BUFFER_CHARS = 8192
        private const val SEGMENT_WINDOW_SIZE = 800
        private const val MERGE_GROUP_FACTOR = 3
    }

    fun streamAndParseUnlimitedFile(
        inputStreamProvider: () -> InputStream,
        format: DocumentFormat,
        estimatedTotalBytes: Long = -1L
    ): Flow<StreamChunkProgress> = flow {
        var chunkIndex = 0
        var totalBytesProcessed = 0L

        inputStreamProvider().use { rawStream ->
            BufferedReader(InputStreamReader(rawStream, StandardCharsets.UTF_8), STREAM_BUFFER_CHARS).use { reader ->
                val buffer = CharArray(STREAM_BUFFER_CHARS)
                var charsRead: Int
                while (reader.read(buffer, 0, buffer.size).also { charsRead = it } != -1) {
                    chunkIndex++
                    val rawChunk = String(buffer, 0, charsRead)
                    val cleaned = rawChunk.trim()
                    val parsedChunk = when (format) {
                        DocumentFormat.PDF -> "[PDF 分块 #$chunkIndex]\n$cleaned"
                        DocumentFormat.DOCX -> "[Word 分块 #$chunkIndex]\n$cleaned"
                        DocumentFormat.MARKDOWN -> "[Markdown 分块 #$chunkIndex]\n$cleaned"
                        DocumentFormat.AUDIO -> "[音频离线转写分块 #$chunkIndex]\n$cleaned"
                        DocumentFormat.IMAGE -> "[OCR 扫描分块 #$chunkIndex]\n$cleaned"
                        DocumentFormat.UNKNOWN -> rawChunk
                        else -> rawChunk
                    }
                    totalBytesProcessed += rawChunk.toByteArray(StandardCharsets.UTF_8).size.toLong()

                    emit(
                        StreamChunkProgress(
                            chunkIndex = chunkIndex,
                            bytesProcessedSoFar = totalBytesProcessed,
                            totalBytesEstimated = estimatedTotalBytes,
                            latestChunkText = parsedChunk,
                            isComplete = false
                        )
                    )
                    delay(15)
                }
            }
        }

        emit(
            StreamChunkProgress(
                chunkIndex = chunkIndex,
                bytesProcessedSoFar = totalBytesProcessed,
                totalBytesEstimated = estimatedTotalBytes,
                latestChunkText = "",
                isComplete = true
            )
        )
    }.flowOn(Dispatchers.IO)

    fun summarizeFullTextHierarchically(
        fullText: String,
        llmConfig: LlmApiConfig
    ): Flow<SummarizationProgress> = flow {
        if (fullText.isBlank()) {
            emit(SummarizationProgress(1, 1, 1, "暂无内容", "暂无内容"))
            return@flow
        }

        // Lossless segmentation across 100% of text (no slice truncation)
        var currentLevelSegments = segmentLosslessly(fullText, SEGMENT_WINDOW_SIZE)
        var currentLevel = 1
        var rollingCarryover = ""

        while (currentLevelSegments.size > 1) {
            val nextLevel = mutableListOf<String>()
            val groups = currentLevelSegments.chunked(MERGE_GROUP_FACTOR)

            for ((gIdx, group) in groups.withIndex()) {
                val combinedGroupText = group.joinToString("\n---\n")
                val groupSummary = if (llmConfig.apiKey.isNotBlank()) {
                    val prompt = "请对以下第 $currentLevel 层第 ${gIdx + 1} 组文本进行滚动摘要提炼（承接前文脉络：$rollingCarryover）：\n$combinedGroupText"
                    llmApiClient.chatCompletion(llmConfig, prompt).getOrElse {
                        localMergeGroup(currentLevel, gIdx, group, rollingCarryover)
                    }
                } else {
                    localMergeGroup(currentLevel, gIdx, group, rollingCarryover)
                }

                rollingCarryover = groupSummary.lines().lastOrNull { it.isNotBlank() } ?: ""
                nextLevel.add(groupSummary)

                emit(
                    SummarizationProgress(
                        currentLevel = currentLevel,
                        processedChunksInLevel = gIdx + 1,
                        totalChunksInLevel = groups.size,
                        intermediateSummaryPreview = groupSummary,
                        finalSummary = null
                    )
                )
                delay(25)
            }
            currentLevelSegments = nextLevel
            currentLevel++
        }

        val rootText = currentLevelSegments.first()
        val finalResult = if (llmConfig.apiKey.isNotBlank()) {
            llmApiClient.chatCompletion(
                llmConfig,
                "请将以下汇总内容整理为结构化知识框架总结（原文共 ${fullText.length} 字，已完成 $currentLevel 层归并）：\n$rootText"
            ).getOrElse { rootText }
        } else {
            rootText
        }

        emit(
            SummarizationProgress(
                currentLevel = currentLevel,
                processedChunksInLevel = 1,
                totalChunksInLevel = 1,
                intermediateSummaryPreview = finalResult,
                finalSummary = finalResult
            )
        )
    }.flowOn(Dispatchers.Default)

    private fun segmentLosslessly(text: String, windowSize: Int): List<String> {
        val result = mutableListOf<String>()
        var cursor = 0
        while (cursor < text.length) {
            val end = (cursor + windowSize).coerceAtMost(text.length)
            result.add(text.substring(cursor, end))
            cursor = end
        }
        return if (result.isEmpty()) listOf(text) else result
    }

    private fun localMergeGroup(
        level: Int,
        groupIndex: Int,
        segments: List<String>,
        carryover: String
    ): String {
        val points = segments.mapIndexed { idx, seg ->
            val sentences = seg.split("。", "！", "？", "\n").map { it.trim() }.filter { it.isNotEmpty() }
            val picked = if (sentences.size <= 2) {
                sentences.joinToString("；")
            } else {
                listOf(sentences.first(), sentences[sentences.size / 2], sentences.last()).distinct().joinToString("；")
            }
            "• 段落组 ${groupIndex * MERGE_GROUP_FACTOR + idx + 1}：$picked"
        }.joinToString("\n")
        val prefix = if (carryover.isNotBlank()) "【承接脉络】$carryover\n" else ""
        return "$prefix[第 $level 层归并 #${groupIndex + 1}]\n$points"
    }
}
