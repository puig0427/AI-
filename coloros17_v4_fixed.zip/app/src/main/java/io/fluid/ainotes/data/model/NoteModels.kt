package io.fluid.ainotes.data.model

enum class AttachmentBadgeType {
    PDF, WORD, AUDIO, LINK, IMAGE, NONE
}

enum class ExportFormat(val extension: String, val displayName: String) {
    PDF("pdf", "PDF 排版文档 (.pdf)"),
    WORD("docx", "Word 文档 (.docx)"),
    TXT("txt", "纯文本 (.txt)"),
    IMAGE("png", "长图卡片 (.png)")
}

enum class DocumentFormat {
    PDF, DOCX, MARKDOWN, AUDIO, IMAGE, UNKNOWN
}

data class TocChapter(
    val id: String,
    val emoji: String,
    val title: String,
    val subItems: List<String>,
    val bodyParagraph: String
)

data class NoteTableData(
    val title: String,
    val headers: List<String>,
    val rows: List<List<String>>
)

data class NoteItem(
    val id: String,
    val title: String,
    val summarySnippet: String,
    val highlightedQuote: String,
    val introParagraph: String,
    val badgeType: AttachmentBadgeType,
    val badgeFileName: String,
    val updatedAt: String,
    val folderName: String,
    val tags: List<String>,
    val chapters: List<TocChapter>,
    val comparisonTable: NoteTableData? = null,
    val rawFullContent: String = "",
    val htmlQuickLookCard: String = ""
)

data class NoteFolder(
    val id: String,
    val name: String,
    val accentHex: Long,
    val noteCount: Int
)

data class SparkBannerData(
    val headline: String,
    val subtitle: String,
    val targetNoteId: String
)

data class ChatMessage(
    val id: String,
    val isUser: Boolean,
    val content: String,
    val timestamp: String
)

data class LlmApiConfig(
    val providerName: String = "DeepSeek / OpenAI 兼容接口",
    val baseUrl: String = "https://api.deepseek.com/v1",
    val apiKey: String = "",
    val modelName: String = "deepseek-chat",
    val systemPrompt: String = "你是 ColorOS 17 小布笔记助手，擅长将长文档、课堂会议记录、外部链接整理为带高亮核心句、章节目录和对比表格的结构化知识框架。"
)

data class StreamChunkProgress(
    val chunkIndex: Int,
    val bytesProcessedSoFar: Long,
    val totalBytesEstimated: Long,
    val latestChunkText: String,
    val isComplete: Boolean = false
)

data class SummarizationProgress(
    val currentLevel: Int,
    val processedChunksInLevel: Int,
    val totalChunksInLevel: Int,
    val intermediateSummaryPreview: String,
    val finalSummary: String? = null
)
