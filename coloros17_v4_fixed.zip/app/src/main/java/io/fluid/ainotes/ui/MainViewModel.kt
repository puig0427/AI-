package io.fluid.ainotes.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import io.fluid.ainotes.data.model.AttachmentBadgeType
import io.fluid.ainotes.data.model.ChatMessage
import io.fluid.ainotes.data.model.DocumentFormat
import io.fluid.ainotes.data.model.LlmApiConfig
import io.fluid.ainotes.data.model.NoteFolder
import io.fluid.ainotes.data.model.NoteItem
import io.fluid.ainotes.data.model.NoteTableData
import io.fluid.ainotes.data.model.SparkBannerData
import io.fluid.ainotes.data.model.StreamChunkProgress
import io.fluid.ainotes.data.model.SummarizationProgress
import io.fluid.ainotes.data.model.TocChapter
import io.fluid.ainotes.data.remote.LlmApiClient
import io.fluid.ainotes.domain.StreamingAndSummaryEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class NotesAppState(
    val notes: List<NoteItem> = emptyList(),
    val folders: List<NoteFolder> = emptyList(),
    val selectedFolderFilter: String? = null,
    val selectedTagFilter: String? = null,
    val searchQuery: String = "",
    val sparkBanner: SparkBannerData = SparkBannerData(
        headline = "嚼透概念才能不卡壳的学习机制",
        subtitle = "知识时刻 | 那个深夜你整理的函数极限笔记",
        targetNoteId = "note_eng_econ"
    ),
    val activeNote: NoteItem? = null,
    val isEditingNote: Boolean = false,
    val chatMessages: List<ChatMessage> = emptyList(),
    val isAiThinking: Boolean = false,
    val llmConfig: LlmApiConfig = LlmApiConfig(),
    val streamProgress: StreamChunkProgress? = null,
    val summaryProgress: SummarizationProgress? = null,
    val toastBanner: String = ""
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val llmApiClient = LlmApiClient(application.applicationContext)
    private val streamingEngine = StreamingAndSummaryEngine(llmApiClient)

    private val _state = MutableStateFlow(NotesAppState())
    val state: StateFlow<NotesAppState> = _state.asStateFlow()

    init {
        val savedConfig = llmApiClient.loadConfig()
        val initialNotes = buildReferenceColorOS17Notes()
        val initialFolders = computeFolders(initialNotes)
        _state.update {
            it.copy(
                notes = initialNotes,
                folders = initialFolders,
                llmConfig = savedConfig
            )
        }
    }

    private fun computeFolders(notes: List<NoteItem>): List<NoteFolder> {
        val grouped = notes.filter { it.folderName.isNotBlank() }.groupBy { it.folderName }
        val colors = listOf(0xFFC084FC, 0xFF60A5FA, 0xFF34D399, 0xFFFBBF24)
        return grouped.entries.mapIndexed { idx, entry ->
            NoteFolder(
                id = "folder_$idx",
                name = entry.key,
                accentHex = colors[idx % colors.size],
                noteCount = entry.value.size
            )
        }
    }

    fun allTagCounts(): List<Pair<String, Int>> {
        val counts = linkedMapOf<String, Int>()
        val defaultTags = listOf(
            "AI科普", "安卓刷机", "笔记库", "避坑指南",
            "大模型", "高等数学", "工程经济学", "GSI",
            "函数极限连续", "黑茶"
        )
        defaultTags.forEach { counts[it] = 1 }
        _state.value.notes.forEach { note ->
            note.tags.forEach { tag ->
                counts[tag] = (counts[tag] ?: 0).coerceAtLeast(1)
            }
        }
        return counts.entries.map { it.key to it.value }
    }

    fun openNote(noteId: String) {
        val found = _state.value.notes.find { it.id == noteId } ?: _state.value.notes.firstOrNull()
        _state.update { it.copy(activeNote = found, isEditingNote = false) }
    }

    fun closeActiveNote() {
        _state.update { it.copy(activeNote = null, isEditingNote = false) }
    }

    fun toggleEditMode(editing: Boolean) {
        _state.update { it.copy(isEditingNote = editing) }
    }

    fun updateActiveNoteContent(newTitle: String, newHighlightedQuote: String, newIntro: String) {
        val current = _state.value.activeNote ?: return
        val updated = current.copy(
            title = newTitle,
            highlightedQuote = newHighlightedQuote,
            summarySnippet = newHighlightedQuote,
            introParagraph = newIntro,
            updatedAt = currentTimestampString() + "更新"
        )
        _state.update { s ->
            val newList = s.notes.map { if (it.id == updated.id) updated else it }
            s.copy(
                notes = newList,
                folders = computeFolders(newList),
                activeNote = updated,
                isEditingNote = false,
                toastBanner = "笔记修改已保存"
            )
        }
    }

    fun addTagToActiveNote(newTag: String) {
        val clean = newTag.trim().removePrefix("#")
        if (clean.isBlank()) return
        val current = _state.value.activeNote ?: return
        if (current.tags.contains(clean)) return
        val updated = current.copy(tags = current.tags + clean)
        _state.update { s ->
            val newList = s.notes.map { if (it.id == updated.id) updated else it }
            s.copy(notes = newList, activeNote = updated)
        }
    }

    fun createNewFolder(folderName: String) {
        val clean = folderName.trim()
        if (clean.isBlank()) return
        val existing = _state.value.folders.any { it.name == clean }
        if (!existing) {
            val newFolder = NoteFolder(
                id = "folder_${System.currentTimeMillis()}",
                name = clean,
                accentHex = 0xFFA855F7,
                noteCount = 0
            )
            _state.update { it.copy(folders = it.folders + newFolder, toastBanner = "已新建笔记库文件夹「$clean」") }
        }
    }

    fun saveLlmConfig(newConfig: LlmApiConfig) {
        llmApiClient.saveConfig(newConfig)
        _state.update {
            it.copy(
                llmConfig = newConfig,
                toastBanner = "大模型 API 配置已保存 (${newConfig.modelName})"
            )
        }
    }

    fun sendAiAssistantMessage(userText: String, scopeLabel: String) {
        val clean = userText.trim()
        if (clean.isBlank()) return
        val nowStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val userMsg = ChatMessage(
            id = "msg_u_${System.currentTimeMillis()}",
            isUser = true,
            content = clean,
            timestamp = nowStr
        )
        _state.update {
            it.copy(
                chatMessages = it.chatMessages + userMsg,
                isAiThinking = true
            )
        }

        viewModelScope.launch {
            val contextSummary = when (scopeLabel) {
                "当前笔记" -> _state.value.activeNote?.let { n ->
                    "标题：${n.title}\n核心句：${n.highlightedQuote}\n简介：${n.introParagraph}"
                } ?: ""
                else -> _state.value.notes.joinToString("\n") { n ->
                    "• 《${n.title}》(${n.folderName})：${n.highlightedQuote}"
                }
            }

            val result = llmApiClient.chatCompletion(
                config = _state.value.llmConfig,
                userPrompt = clean,
                contextNotesSummary = contextSummary
            )

            val replyContent = result.fold(
                onSuccess = { it },
                onFailure = { err ->
                    "⚠️ 调用大模型接口出错：${err.message}\n请检查右上角/设置中的 Base URL、API Key 与模型名称是否正确。"
                }
            )

            val aiMsg = ChatMessage(
                id = "msg_a_${System.currentTimeMillis()}",
                isUser = false,
                content = replyContent,
                timestamp = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            )
            _state.update {
                it.copy(
                    chatMessages = it.chatMessages + aiMsg,
                    isAiThinking = false
                )
            }
        }
    }

    fun clearChatHistory() {
        _state.update { it.copy(chatMessages = emptyList()) }
    }

    fun importUnlimitedStreamToNote(
        fileName: String,
        format: DocumentFormat,
        badgeType: AttachmentBadgeType,
        folderName: String = "考研",
        inputStreamProvider: () -> InputStream,
        estimatedBytes: Long = -1L
    ) {
        viewModelScope.launch {
            val rawBuilder = StringBuilder()
            streamingEngine.streamAndParseUnlimitedFile(
                inputStreamProvider = inputStreamProvider,
                format = format,
                estimatedTotalBytes = estimatedBytes
            ).collect { prog ->
                if (prog.latestChunkText.isNotEmpty()) {
                    if (rawBuilder.isNotEmpty()) rawBuilder.append("\n")
                    rawBuilder.append(prog.latestChunkText)
                }
                _state.update {
                    it.copy(
                        streamProgress = prog,
                        toastBanner = if (!prog.isComplete) {
                            "流式读取 $fileName：分块 #${prog.chunkIndex} (${prog.bytesProcessedSoFar} B)"
                        } else {
                            "流式读取完成，正在进行全量无截断层级总结..."
                        }
                    )
                }
            }

            val fullRawText = rawBuilder.toString()
            var finalHierarchicalSummary = ""
            streamingEngine.summarizeFullTextHierarchically(
                fullText = fullRawText,
                llmConfig = _state.value.llmConfig
            ).collect { sumProg ->
                _state.update { it.copy(summaryProgress = sumProg) }
                if (sumProg.finalSummary != null) {
                    finalHierarchicalSummary = sumProg.finalSummary
                }
            }

            val cleanTitle = fileName.substringBeforeLast(".").ifBlank { "新建流式智能笔记" }
            val firstGoldenLine = finalHierarchicalSummary.lines()
                .map { it.trim().removePrefix("•").trim() }
                .firstOrNull { it.length >= 8 }
                ?: "全量流式分块与层级合并，确保每一处细节与核心概念都不被遗漏。"

            val newNote = NoteItem(
                id = "note_${System.currentTimeMillis()}",
                title = cleanTitle,
                summarySnippet = firstGoldenLine,
                highlightedQuote = firstGoldenLine,
                introParagraph = "本笔记由 ColorOS 17 流式引擎无损导入（原文共 ${fullRawText.length} 字，零截断全覆盖总结）。",
                badgeType = badgeType,
                badgeFileName = fileName,
                updatedAt = currentTimestampString() + "更新",
                folderName = folderName,
                tags = listOf(folderName, "AI整理", format.name),
                chapters = listOf(
                    TocChapter(
                        id = "ch_overview",
                        emoji = "📋",
                        title = "全篇核心框架",
                        subItems = listOf("全文层级归并脉络", "关键结论提炼"),
                        bodyParagraph = finalHierarchicalSummary
                    ),
                    TocChapter(
                        id = "ch_raw",
                        emoji = "🔍",
                        title = "第1章：流式解析原文节选与要点",
                        subItems = listOf("核心概念辨析", "流式分块明细"),
                        bodyParagraph = fullRawText
                    )
                ),
                comparisonTable = NoteTableData(
                    title = "核心概念辨析",
                    headers = listOf("概念", "核心定义与考点"),
                    rows = listOf(
                        listOf("流式分块读取", "8KB 缓冲区 + Kotlin Flow，无 maxFileSize 限制"),
                        listOf("层级合并总结", "分段总结 → 滚动汇总 → 树状合并，全文 0% 截断"),
                        listOf("来源文件", fileName)
                    )
                ),
                rawFullContent = fullRawText
            )

            _state.update { s ->
                val updatedNotes = listOf(newNote) + s.notes
                s.copy(
                    notes = updatedNotes,
                    folders = computeFolders(updatedNotes),
                    activeNote = newNote,
                    streamProgress = null,
                    summaryProgress = null,
                    toastBanner = "已生成结构化笔记《$cleanTitle》"
                )
            }
        }
    }

    fun triggerQuickCreationAction(actionType: String, customInput: String = "") {
        val sampleText = when (actionType) {
            "会议笔记" -> buildString {
                appendLine("会议主题：2026 秋季产品架构与考研复习方法论研讨")
                appendLine("发言人 A（主讲）：今天我们重点讨论如何把复杂教材拆解为可执行的知识框架。嚼透概念才能不卡壳。")
                appendLine("发言人 B（教研）：赞同，比如工程经济学里，核心就是比选增量而非总量，关注机会成本而非沉没成本。")
                appendLine("决议事项：所有科目笔记统一采用【高亮金句 + 章节折叠目录 + 核心概念对比表格】三段式呈现。")
            }
            "说想法" -> customInput.ifBlank {
                "今天复习高等数学函数极限时突然意识到，左极限和右极限相等且等于函数值是连续的充要条件，已自动去除语气词并提炼为知识卡片。"
            }
            "链接" -> buildString {
                appendLine("来源链接：${customInput.ifBlank { "https://www.xiaohongshu.com/explore/coloros17-ai-notes" }}")
                appendLine("自动提取正文与字幕要点：")
                appendLine("1. 把 AI 当成经验丰富的新员工，给足上下文和结构化模板，而不是只丢一句模糊指令；")
                appendLine("2. 善用笔记库分类与 #标签 聚合，复习时直接打开目录抽屉即可秒定位考点。")
            }
            "扫描" -> buildString {
                appendLine("【纸质教材拍照扫描 OCR】")
                appendLine("第2章：工程项目投资现金流量识别与估算")
                appendLine("• 项目增量投资三种分类角度：新设法人项目、既有法人增量分析、改扩建边际贡献。")
                appendLine("• 现金流量核心三要素：现金流入 (CI)、现金流出 (CO)、净现金流量 (NCF = CI - CO)。")
            }
            "音频" -> buildString {
                appendLine("【离线语音转写 · 区分说话人】")
                appendLine("[00:00 - 00:25] 讲师：黑茶的苦，多半不是茶的错，是水不够沸、汤没倒干净。")
                appendLine("[00:26 - 00:58] 学员：明白了，润茶时沸水高冲、快速出汤，就能避免闷出苦涩味。")
            }
            else -> customInput.ifBlank { "随手记录灵感要点，支持随时唤起问小布与结构化排版。" }
        }

        val fileName = when (actionType) {
            "会议笔记" -> "会议纪要_${System.currentTimeMillis() % 1000}.mp3"
            "说想法" -> "语音速记_${System.currentTimeMillis() % 1000}.m4a"
            "链接" -> "网页外链智能抓取_${System.currentTimeMillis() % 1000}.url"
            "扫描" -> "纸质资料扫描件_${System.currentTimeMillis() % 1000}.pdf"
            "音频" -> "课堂录音转写_${System.currentTimeMillis() % 1000}.wav"
            else -> "新建笔记_${System.currentTimeMillis() % 1000}.docx"
        }

        val badge = when (actionType) {
            "会议笔记", "说想法", "音频" -> AttachmentBadgeType.AUDIO
            "链接" -> AttachmentBadgeType.LINK
            "扫描" -> AttachmentBadgeType.PDF
            else -> AttachmentBadgeType.WORD
        }

        val bytes = sampleText.toByteArray(StandardCharsets.UTF_8)
        importUnlimitedStreamToNote(
            fileName = fileName,
            format = DocumentFormat.MARKDOWN,
            badgeType = badge,
            folderName = "考研",
            inputStreamProvider = { ByteArrayInputStream(bytes) },
            estimatedBytes = bytes.size.toLong()
        )
    }

    private fun currentTimestampString(): String {
        return SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()).format(Date())
    }

    private fun buildReferenceColorOS17Notes(): List<NoteItem> {
        return listOf(
            NoteItem(
                id = "note_eng_econ",
                title = "工程经济学第5版知识框架",
                summarySnippet = "工程经济分析核心是，比选增量而非总量，关注机...",
                highlightedQuote = "工程经济分析核心是，比选增量而非总量，关注机会而非沉没。",
                introParagraph = "本整理为同济大学出版社《工程经济学（第5版）》全书10章完整知识体系，包含每章知识脉络、核心概念、计算公式、高频考点，覆盖考研与执业考试全部考点。",
                badgeType = AttachmentBadgeType.PDF,
                badgeFileName = "工程经济学_教材原话完整知识体系框架.pdf",
                updatedAt = "2026/10/28 10:36更新",
                folderName = "考研",
                tags = listOf("工程经济学", "考研复习", "学科知识", "注册考试"),
                chapters = listOf(
                    TocChapter(
                        id = "ch_0",
                        emoji = "📋",
                        title = "全书核心框架",
                        subItems = emptyList(),
                        bodyParagraph = "按工程经济分析逻辑，从基本概念出发，逐步展开现金流量估算、资金时间价值、评价指标、折旧与所得税、盈利清偿分析、设备更新、公共项目、不确定性分析、价值工程，最终汇总核心评价指标公式表。"
                    ),
                    TocChapter(
                        id = "ch_1",
                        emoji = "🔍",
                        title = "第1章：基本概念",
                        subItems = listOf("核心概念辨析", "工程经济分析五大原则", "核心原理"),
                        bodyParagraph = "本章为全书理论基石，重点考察工程技术两重性、研究对象、五大分析原则与成本概念辨析，常考选择与简答题。"
                    ),
                    TocChapter(
                        id = "ch_2",
                        emoji = "📊",
                        title = "第2章：工程项目投资现金流量识别与估算",
                        subItems = listOf("项目增量投资三种分类角度", "现金流量核心要素", "资金等值计算公式表"),
                        bodyParagraph = "准确识别增量现金流量是项目经济评价的前提，需严格区分机会成本、沉没成本、经营成本与折旧摊销。"
                    )
                ),
                comparisonTable = NoteTableData(
                    title = "核心概念辨析",
                    headers = listOf("概念", "核心定义与考点"),
                    rows = listOf(
                        listOf("机会成本", "将有限资源用于某项目而放弃的最佳替代用途收益（必计入现金流出）"),
                        listOf("沉没成本", "过去已经发生、不受当前决策影响的历史成本（决策时坚决剔除）"),
                        listOf("经营成本", "总成本费用扣除折旧费、摊销费和利息支出后的付现成本")
                    )
                ),
                rawFullContent = "同济大学出版社《工程经济学（第5版）》全书10章完整知识体系。"
            ),
            NoteItem(
                id = "note_dark_tea",
                title = "黑茶冲泡实操指南",
                summarySnippet = "黑茶的苦，多半不是茶的错，是水不够沸、汤没倒...",
                highlightedQuote = "黑茶的苦，多半不是茶的错，是水不够沸、汤没倒干净。",
                introParagraph = "针对安化黑茶、普洱熟茶及六堡茶的标准化冲泡流程整理，涵盖备器、温杯、润茶、沸水定点高冲及坐杯时间控制。",
                badgeType = AttachmentBadgeType.WORD,
                badgeFileName = "30ba2e02_6a781ab832d241f5759e848493d410...",
                updatedAt = "2026/10/28 10:35更新",
                folderName = "",
                tags = listOf("黑茶", "避坑指南"),
                chapters = listOf(
                    TocChapter(
                        id = "tea_1",
                        emoji = "📋",
                        title = "核心冲泡三要素",
                        subItems = listOf("水温控制（100℃沸水）", "茶水比（1:20）", "出汤沥干不留根"),
                        bodyParagraph = "老黑茶内质丰厚，唯有真沸水才能激发陈香与木质香；每一泡出汤必须沥尽公道杯与盖碗余水，避免余汤闷泡发苦。"
                    )
                ),
                comparisonTable = NoteTableData(
                    title = "不同年份黑茶冲泡参数表",
                    headers = listOf("茶品类型", "建议水温与出汤时间"),
                    rows = listOf(
                        listOf("3~5年新压黑砖/茯砖", "100℃沸水，润茶1次，前3泡5秒即出"),
                        listOf("10年以上陈年老黑茶", "100℃沸水或陶壶煮饮，润茶2次，风味更醇厚")
                    )
                )
            ),
            NoteItem(
                id = "note_doc_pen",
                title = "文档笔记",
                summarySnippet = "",
                highlightedQuote = "嚼透概念才能不卡壳的学习机制：用费曼输出倒逼输入。",
                introParagraph = "高等数学函数极限与连续性深夜复盘手记，梳理无穷小阶的比较、泰勒展开截断阶数与洛必达法则使用前提。",
                badgeType = AttachmentBadgeType.AUDIO,
                badgeFileName = "6d563ca7_5c8c93df0293d20ad40417f4d67d099...",
                updatedAt = "2026/10/28 10:30更新",
                folderName = "",
                tags = listOf("高等数学", "函数极限连续", "笔记库"),
                chapters = listOf(
                    TocChapter(
                        id = "math_1",
                        emoji = "🔍",
                        title = "第1章：函数极限与连续核心定理",
                        subItems = listOf("夹逼准则与单调有界", "等价无穷小代换禁忌"),
                        bodyParagraph = "加减法中切忌直接盲目使用等价无穷小代换，唯有乘除因子或满足高阶无穷小余项抵消条件时方可替换。"
                    )
                )
            ),
            NoteItem(
                id = "note_ai_agent",
                title = "AI聊天与智能体区别",
                summarySnippet = "把AI当经验丰富的新员工，而非只会执行指令的...",
                highlightedQuote = "把AI当经验丰富的新员工，而非只会执行指令的搜索框。",
                introParagraph = "深入对比传统单轮问答 Chatbot 与具备规划（Planning）、记忆（Memory）、工具调用（Tool Use）能力的 AI Agent 智能体。",
                badgeType = AttachmentBadgeType.LINK,
                badgeFileName = "如果你只是跟豆包千问这些AI软件聊聊天...",
                updatedAt = "2026/10/27 11:53更新",
                folderName = "",
                tags = listOf("AI科普", "大模型", "安卓刷机", "GSI"),
                chapters = listOf(
                    TocChapter(
                        id = "ai_1",
                        emoji = "📋",
                        title = "AI 聊天与 Agent 智能体核心差异",
                        subItems = listOf("被动问答 vs 主动拆解任务", "上下文记忆与外部工具挂载"),
                        bodyParagraph = "传统聊天是一问一答；智能体则能接收目标后自主规划步骤、检索本地笔记库并输出结构化文档。"
                    )
                )
            )
        )
    }
}
