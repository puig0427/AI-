package io.fluid.ainotes

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import io.fluid.ainotes.ui.MainViewModel
import io.fluid.ainotes.ui.screens.ColorOS17RealNotesScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val mainViewModel: MainViewModel = viewModel()
            ColorOS17RealNotesScreen(viewModel = mainViewModel)
        }
    }
}
