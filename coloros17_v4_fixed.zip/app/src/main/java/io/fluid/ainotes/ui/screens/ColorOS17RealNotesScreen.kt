package io.fluid.ainotes.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.FormatListBulleted
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.UnfoldMore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.fluid.ainotes.data.model.AttachmentBadgeType
import io.fluid.ainotes.data.model.DocumentFormat
import io.fluid.ainotes.data.model.LlmApiConfig
import io.fluid.ainotes.data.model.NoteFolder
import io.fluid.ainotes.data.model.NoteItem
import io.fluid.ainotes.ui.MainViewModel
import io.fluid.ainotes.ui.NotesAppState
import kotlinx.coroutines.launch
import java.io.ByteArrayInputStream

private val BgGray = Color(0xFFF6F6F6)
private val CardWhite = Color(0xFFFFFFFF)
private val PillGray = Color(0xFFF2F2F4)
private val TextPrimary = Color(0xFF141414)
private val TextSecondary = Color(0xFF757575)
private val SparkOrange = Color(0xFFF97316)
private val HighlightWarm = Color(0xFFFDE6C4)
private val PdfRed = Color(0xFFEA4335)
private val WordBlue = Color(0xFF3B6EF6)

enum class BottomMainTab {
    NOTES, NOTE_LIBRARY
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ColorOS17RealNotesScreen(viewModel: MainViewModel) {
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current

    var currentTab by remember { mutableStateOf(BottomMainTab.NOTES) }
    var showSearchOverlay by remember { mutableStateOf(false) }
    var showPlusCreateOverlay by remember { mutableStateOf(false) }
    var showMoreConvertSheet by remember { mutableStateOf(false) }
    var showAiAssistantScreen by remember { mutableStateOf(false) }
    var showTocBottomSheet by remember { mutableStateOf(false) }
    var showApiSettingsDialog by remember { mutableStateOf(false) }
    var showNewFolderDialog by remember { mutableStateOf(false) }
    var showLinkInputDialog by remember { mutableStateOf(false) }

    // SAF Unlimited File Picker
    val safDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val seg = uri.lastPathSegment ?: "导入文档.pdf"
            val isPdf = seg.endsWith(".pdf", true)
            val isWord = seg.endsWith(".docx", true) || seg.endsWith(".doc", true)
            viewModel.importUnlimitedStreamToNote(
                fileName = seg,
                format = when {
                    isPdf -> DocumentFormat.PDF
                    isWord -> DocumentFormat.DOCX
                    else -> DocumentFormat.MARKDOWN
                },
                badgeType = if (isPdf) AttachmentBadgeType.PDF else AttachmentBadgeType.WORD,
                inputStreamProvider = {
                    context.contentResolver.openInputStream(uri)
                        ?: ByteArrayInputStream("流式读取内容".toByteArray())
                }
            )
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BgGray)
    ) {
        // 1. Underlying Home / Note Library Screen
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
        ) {
            // Top Bar (Search circle button + More circle button)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircleIconButton(
                    icon = Icons.Default.Search,
                    onClick = { showSearchOverlay = true }
                )
                Spacer(modifier = Modifier.width(12.dp))
                CircleIconButton(
                    icon = Icons.Default.MoreVert,
                    onClick = { showApiSettingsDialog = true }
                )
            }

            if (currentTab == BottomMainTab.NOTES) {
                NotesHomeTabContent(
                    state = state,
                    onOpenNote = { viewModel.openNote(it) },
                    onClearFilter = {
                        // Reset filter
                    }
                )
            } else {
                NoteLibraryTabContent(
                    state = state,
                    onSelectFolder = { folderName ->
                        currentTab = BottomMainTab.NOTES
                    }
                )
            }
        }

        // Streaming / Summarization Progress Floating Banner
        if (state.streamProgress != null || state.summaryProgress != null) {
            Surface(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(top = 60.dp, start = 20.dp, end = 20.dp)
                    .fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = Color(0xFF1E293B),
                shadowElevation = 10.dp
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = state.toastBanner.ifBlank { "正在流式处理并生成结构化总结..." },
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape),
                        color = SparkOrange
                    )
                }
            }
        }

        // 2. Bottom 3-Part Floating Dock (Screenshot 1 & 2 exact replica)
        if (!showPlusCreateOverlay && state.activeNote == null && !showSearchOverlay && !showAiAssistantScreen) {
            BottomThreePartFloatingBar(
                currentTab = currentTab,
                onSelectTab = { currentTab = it },
                onClickLeftRainbowAi = { showAiAssistantScreen = true },
                onClickRightAction = {
                    if (currentTab == BottomMainTab.NOTES) {
                        showPlusCreateOverlay = true
                    } else {
                        showNewFolderDialog = true
                    }
                },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
            )
        }

        // 3. Screenshot 7: Blurred "+" Creation Overlay (会议笔记 / 说想法 / 写笔记 / 更多内容转笔记 / 左下角设置齿轮)
        AnimatedVisibility(
            visible = showPlusCreateOverlay,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            PlusCreationBlurredOverlay(
                onDismiss = { showPlusCreateOverlay = false },
                onClickSettings = {
                    showPlusCreateOverlay = false
                    showApiSettingsDialog = true
                },
                onTriggerAction = { actionType ->
                    showPlusCreateOverlay = false
                    if (actionType == "写笔记") {
                        viewModel.triggerQuickCreationAction("写笔记")
                    } else {
                        viewModel.triggerQuickCreationAction(actionType)
                    }
                },
                onClickMoreConvert = {
                    showPlusCreateOverlay = false
                    showMoreConvertSheet = true
                }
            )
        }

        // 4. Screenshot 3: Search & Tag Filter Screen
        AnimatedVisibility(
            visible = showSearchOverlay,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            SearchAndTagScreen(
                tagsWithCounts = viewModel.allTagCounts(),
                notes = state.notes,
                onDismiss = { showSearchOverlay = false },
                onSelectNote = { noteId ->
                    showSearchOverlay = false
                    viewModel.openNote(noteId)
                }
            )
        }

        // 5. Screenshot 4, 5, 6: Note Detail & Edit Screen
        AnimatedVisibility(
            visible = state.activeNote != null,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            state.activeNote?.let { note ->
                NoteDetailAndEditScreen(
                    note = note,
                    isEditing = state.isEditingNote,
                    onBack = { viewModel.closeActiveNote() },
                    onOpenTocSheet = { showTocBottomSheet = true },
                    onOpenAiAssistant = { showAiAssistantScreen = true },
                    onToggleEdit = { viewModel.toggleEditMode(it) },
                    onSaveEditedNote = { t, q, i ->
                        viewModel.updateActiveNoteContent(t, q, i)
                    },
                    onAddTag = { viewModel.addTagToActiveNote(it) }
                )
            }
        }

        // 6. Screenshot 9: "Hi，我是你的笔记助手" Full-Screen AI Assistant
        AnimatedVisibility(
            visible = showAiAssistantScreen,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            AiAssistantFullScreen(
                state = state,
                onBack = { showAiAssistantScreen = false },
                onOpenApiSettings = { showApiSettingsDialog = true },
                onClearHistory = { viewModel.clearChatHistory() },
                onSendMessage = { msg, scope ->
                    viewModel.sendAiAssistantMessage(msg, scope)
                }
            )
        }

        // 7. Screenshot 5: "目录" (Table of Contents) Modal Bottom Sheet
        if (showTocBottomSheet && state.activeNote != null) {
            val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
            ModalBottomSheet(
                onDismissRequest = { showTocBottomSheet = false },
                sheetState = sheetState,
                containerColor = BgGray,
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
            ) {
                TocBottomSheetContent(
                    note = state.activeNote!!,
                    onClose = { showTocBottomSheet = false }
                )
            }
        }

        // 8. Screenshot 8: "更多内容转笔记" Modal Bottom Sheet
        if (showMoreConvertSheet) {
            val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
            ModalBottomSheet(
                onDismissRequest = { showMoreConvertSheet = false },
                sheetState = sheetState,
                containerColor = BgGray,
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
            ) {
                MoreContentToNoteSheet(
                    onClose = { showMoreConvertSheet = false },
                    onClickLink = {
                        showMoreConvertSheet = false
                        showLinkInputDialog = true
                    },
                    onClickScan = {
                        showMoreConvertSheet = false
                        viewModel.triggerQuickCreationAction("扫描")
                    },
                    onClickImage = {
                        showMoreConvertSheet = false
                        viewModel.triggerQuickCreationAction("扫描")
                    },
                    onClickDocument = {
                        showMoreConvertSheet = false
                        safDocumentLauncher.launch(
                            arrayOf(
                                "application/pdf",
                                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                "text/markdown",
                                "text/plain"
                            )
                        )
                    },
                    onClickAudio = {
                        showMoreConvertSheet = false
                        viewModel.triggerQuickCreationAction("音频")
                    },
                    onClickBreenoMemory = {
                        showMoreConvertSheet = false
                        viewModel.triggerQuickCreationAction("说想法", "基于小布记忆素材：自动汇总近期保存的截图、网页与复习重点生成结构化笔记。")
                    }
                )
            }
        }

        // 9. Custom LLM API Configuration Dialog
        if (showApiSettingsDialog) {
            LlmApiSettingsDialog(
                currentConfig = state.llmConfig,
                onDismiss = { showApiSettingsDialog = false },
                onSave = { newCfg ->
                    viewModel.saveLlmConfig(newCfg)
                    showApiSettingsDialog = false
                }
            )
        }

        // 10. New Folder Dialog
        if (showNewFolderDialog) {
            var folderInput by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { showNewFolderDialog = false },
                title = { Text("新建笔记库文件夹", fontWeight = FontWeight.Bold) },
                text = {
                    OutlinedTextField(
                        value = folderInput,
                        onValueChange = { folderInput = it },
                        label = { Text("输入文件夹名称（如：专业课、英语）") },
                        singleLine = true
                    )
                },
                confirmButton = {
                    Button(onClick = {
                        viewModel.createNewFolder(folderInput)
                        showNewFolderDialog = false
                    }) {
                        Text("创建")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showNewFolderDialog = false }) {
                        Text("取消")
                    }
                }
            )
        }

        // 11. External Link Input Dialog
        if (showLinkInputDialog) {
            var linkUrl by remember { mutableStateOf("https://www.bilibili.com/video/BV1ColorOS17Notes") }
            AlertDialog(
                onDismissRequest = { showLinkInputDialog = false },
                title = { Text("链接转笔记（小红书 / B站 / 公众号）", fontWeight = FontWeight.Bold) },
                text = {
                    OutlinedTextField(
                        value = linkUrl,
                        onValueChange = { linkUrl = it },
                        label = { Text("粘贴网页或视频链接") },
                        singleLine = true
                    )
                },
                confirmButton = {
                    Button(onClick = {
                        viewModel.triggerQuickCreationAction("链接", linkUrl)
                        showLinkInputDialog = false
                    }) {
                        Text("解析生成笔记")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showLinkInputDialog = false }) {
                        Text("取消")
                    }
                }
            )
        }
    }
}

/**
 * Screenshot 1: Home Tab ("✳ 灵光一刻" header + "全部 16" + White rounded cards with file pill badges)
 */
@Composable
fun NotesHomeTabContent(
    state: NotesAppState,
    onOpenNote: (String) -> Unit,
    onClearFilter: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 4.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. ✳ 灵光一刻 Header Section
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenNote(state.sparkBanner.targetNoteId) }
                    .padding(vertical = 4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SparkAsteriskIcon(modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "灵光一刻",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = state.sparkBanner.headline,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = CardWhite,
                        shadowElevation = 2.dp,
                        modifier = Modifier.size(width = 40.dp, height = 26.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                tint = TextPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = state.sparkBanner.subtitle,
                    fontSize = 13.sp,
                    color = TextSecondary
                )
            }
        }

        // 2. "全部 16" & "筛选" Header Row
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp, bottom = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = "全部",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "${state.notes.size + 12}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextSecondary
                    )
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onClearFilter() }
                ) {
                    Text(
                        text = "筛选",
                        fontSize = 14.sp,
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.FilterList,
                        contentDescription = "筛选",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // 3. Note Cards List (Exact Screenshot 1 layout)
        items(state.notes, key = { it.id }) { note ->
            ColorOS17NoteCard(
                note = note,
                onClick = { onOpenNote(note.id) }
            )
        }
    }
}

@Composable
fun ColorOS17NoteCard(
    note: NoteItem,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(24.dp),
        color = CardWhite,
        shadowElevation = 0.5.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 18.dp)
        ) {
            Text(
                text = note.title,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            if (note.summarySnippet.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = note.summarySnippet,
                    fontSize = 14.sp,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (note.badgeFileName.isNotBlank()) {
                Spacer(modifier = Modifier.height(12.dp))
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color(0xFFF5F5F7),
                    modifier = Modifier.fillMaxWidth(0.92f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AttachmentBadgeIcon(note.badgeType)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = note.badgeFileName,
                            fontSize = 13.sp,
                            color = Color(0xFF424242),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val metaText = if (note.folderName.isNotBlank()) {
                    "${note.updatedAt} | ${note.folderName}"
                } else {
                    note.updatedAt
                }
                Text(
                    text = metaText,
                    fontSize = 12.sp,
                    color = Color(0xFF8C8C8C)
                )
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "更多",
                    tint = Color(0xFF8C8C8C),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun AttachmentBadgeIcon(type: AttachmentBadgeType) {
    when (type) {
        AttachmentBadgeType.PDF -> {
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(PdfRed),
                contentAlignment = Alignment.Center
            ) {
                Text("PDF", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
            }
        }
        AttachmentBadgeType.WORD -> {
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(WordBlue),
                contentAlignment = Alignment.Center
            ) {
                Text("W", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
        AttachmentBadgeType.AUDIO -> {
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF262626)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(11.dp)
                )
            }
        }
        AttachmentBadgeType.LINK -> {
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(Color(0xFF8C8C8C)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Link,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(13.dp)
                )
            }
        }
        else -> {
            Icon(
                imageVector = Icons.Default.Description,
                contentDescription = null,
                tint = WordBlue,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

/**
 * Screenshot 2: "笔记库" (Note Library) Tab with Skeuomorphic Frosted White Folder + Purple Tab
 */
@Composable
fun NoteLibraryTabContent(
    state: NotesAppState,
    onSelectFolder: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 22.dp)
    ) {
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "笔记库",
            fontSize = 30.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
        Spacer(modifier = Modifier.height(18.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = "全部",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "${state.folders.size}",
                    fontSize = 16.sp,
                    color = TextSecondary
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "排序",
                    fontSize = 14.sp,
                    color = TextPrimary
                )
                Icon(
                    imageVector = Icons.Default.UnfoldMore,
                    contentDescription = "排序",
                    tint = TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            items(state.folders, key = { it.id }) { folder ->
                SkeuomorphicFolderCard(
                    folder = folder,
                    onClick = { onSelectFolder(folder.name) }
                )
            }
        }
    }
}

@Composable
fun SkeuomorphicFolderCard(
    folder: NoteFolder,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(120.dp)
            .clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(width = 114.dp, height = 96.dp)
        ) {
            // Back folder tab
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(82.dp)
                    .align(Alignment.BottomCenter)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0xFFEAECEF))
            )
            // Top left folder ear
            Box(
                modifier = Modifier
                    .size(width = 48.dp, height = 22.dp)
                    .offset(x = 6.dp, y = 6.dp)
                    .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 10.dp))
                    .background(Color(0xFFEAECEF))
            )
            // Purple / Accent bookmark tab inside folder
            Box(
                modifier = Modifier
                    .size(width = 38.dp, height = 16.dp)
                    .align(Alignment.TopEnd)
                    .offset(x = (-14).dp, y = 11.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(folder.accentHex))
            )
            // Front frosted white folder body
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(74.dp)
                    .align(Alignment.BottomCenter),
                shape = RoundedCornerShape(18.dp),
                color = Color(0xFFFAFAFC),
                shadowElevation = 4.dp
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color.White,
                                    Color(0xFFF3F4F6)
                                )
                            )
                        )
                )
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = folder.name,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = "${folder.noteCount}",
            fontSize = 12.sp,
            color = TextSecondary
        )
    }
}

/**
 * Screenshot 1 & 2 Bottom 3-Part Floating Navigation Bar:
 * - Left: White circle with colorful 4-loop AI ribbon icon
 * - Center: White pill with "笔记" and "笔记库"
 * - Right: Black circle with "+" (or folder+ on Note Library tab)
 */
@Composable
fun BottomThreePartFloatingBar(
    currentTab: BottomMainTab,
    onSelectTab: (BottomMainTab) -> Unit,
    onClickLeftRainbowAi: () -> Unit,
    onClickRightAction: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 22.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left: White Circle AI Button with 4-color Breeno Ribbon
        Surface(
            modifier = Modifier
                .size(58.dp)
                .clickable { onClickLeftRainbowAi() },
            shape = CircleShape,
            color = CardWhite,
            shadowElevation = 8.dp
        ) {
            Box(contentAlignment = Alignment.Center) {
                ColorfulBreenoRibbonIcon(modifier = Modifier.size(28.dp))
            }
        }

        // Center: Floating White Pill ("笔记" | "笔记库")
        Surface(
            modifier = Modifier
                .width(196.dp)
                .height(60.dp),
            shape = RoundedCornerShape(50),
            color = CardWhite.copy(alpha = 0.96f),
            shadowElevation = 8.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Tab 1: 笔记
                val notesSelected = currentTab == BottomMainTab.NOTES
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onSelectTab(BottomMainTab.NOTES) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Description,
                        contentDescription = "笔记",
                        tint = if (notesSelected) TextPrimary else TextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "笔记",
                        fontSize = 11.sp,
                        fontWeight = if (notesSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (notesSelected) TextPrimary else TextSecondary
                    )
                }

                // Tab 2: 笔记库
                val libSelected = currentTab == BottomMainTab.NOTE_LIBRARY
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onSelectTab(BottomMainTab.NOTE_LIBRARY) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Folder,
                        contentDescription = "笔记库",
                        tint = if (libSelected) TextPrimary else TextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "笔记库",
                        fontSize = 11.sp,
                        fontWeight = if (libSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (libSelected) TextPrimary else TextSecondary
                    )
                }
            }
        }

        // Right: Solid Black Circle "+" or "New Folder" Button
        Surface(
            modifier = Modifier
                .size(58.dp)
                .clickable { onClickRightAction() },
            shape = CircleShape,
            color = Color(0xFF141414),
            shadowElevation = 8.dp
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = if (currentTab == BottomMainTab.NOTES) {
                        Icons.Default.Add
                    } else {
                        Icons.Default.CreateNewFolder
                    },
                    contentDescription = "新建",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    }
}

/**
 * Screenshot 3: Search & Tag Cloud Screen ("在全部笔记中搜索" + "取消" + "# AI科普 1" tag pills)
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SearchAndTagScreen(
    tagsWithCounts: List<Pair<String, Int>>,
    notes: List<NoteItem>,
    onDismiss: () -> Unit,
    onSelectNote: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var selectedTag by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgGray)
            .statusBarsPadding()
            .padding(horizontal = 18.dp, vertical = 10.dp)
    ) {
        // Search Bar + Cancel Pill Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(50),
                color = CardWhite
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = TextPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    androidx.compose.foundation.text.BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        decorationBox = { innerTextField ->
                            if (query.isEmpty()) {
                                Text("在全部笔记中搜索", color = Color(0xFF9E9E9E), fontSize = 15.sp)
                            }
                            innerTextField()
                        }
                    )
                }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Surface(
                modifier = Modifier
                    .height(48.dp)
                    .clickable { onDismiss() },
                shape = RoundedCornerShape(50),
                color = CardWhite
            ) {
                Box(
                    modifier = Modifier.padding(horizontal = 20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("取消", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "标签",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
        Spacer(modifier = Modifier.height(14.dp))

        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            tagsWithCounts.forEach { (tag, count) ->
                val isSelected = selectedTag == tag
                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (isSelected) TextPrimary else Color(0xFFE9E9EC),
                    modifier = Modifier.clickable {
                        selectedTag = if (isSelected) null else tag
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "#",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.White else TextPrimary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = tag,
                            fontSize = 13.sp,
                            color = if (isSelected) Color.White else TextPrimary
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = "$count",
                            fontSize = 13.sp,
                            color = if (isSelected) Color.LightGray else TextSecondary
                        )
                    }
                }
            }
        }

        val filtered = notes.filter { n ->
            val matchesQuery = query.isBlank() ||
                n.title.contains(query, true) ||
                n.highlightedQuote.contains(query, true) ||
                n.introParagraph.contains(query, true)
            val matchesTag = selectedTag == null || n.tags.contains(selectedTag)
            matchesQuery && matchesTag
        }

        if (query.isNotBlank() || selectedTag != null) {
            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "匹配结果 (${filtered.size})",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(10.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(filtered, key = { it.id }) { item ->
                    ColorOS17NoteCard(note = item, onClick = { onSelectNote(item.id) })
                }
            }
        }
    }
}

/**
 * Screenshot 4, 5, 6: Note Detail & Edit Mode Screen
 * - Top bar: Back circle + TOC list circle + Share/Undo/Redo + More/完成
 * - Tag chips row: "+" + "工程经济学" + "考研复习" + "学科知识" + "注册考试"
 * - Warm orange marker highlight on key takeaway sentence
 * - Chapters with emoji icons ("📋 全书核心框架", "🔍 第1章：基本概念")
 * - Embedded table card with expand icon
 * - Bottom floating pill: "问小布" | "编辑" (or "格式 | @ | 图片 | +" in Edit mode)
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NoteDetailAndEditScreen(
    note: NoteItem,
    isEditing: Boolean,
    onBack: () -> Unit,
    onOpenTocSheet: () -> Unit,
    onOpenAiAssistant: () -> Unit,
    onToggleEdit: (Boolean) -> Unit,
    onSaveEditedNote: (String, String, String) -> Unit,
    onAddTag: (String) -> Unit
) {
    var editTitle by remember(note.id) { mutableStateOf(note.title) }
    var editQuote by remember(note.id) { mutableStateOf(note.highlightedQuote) }
    var editIntro by remember(note.id) { mutableStateOf(note.introParagraph) }
    var showAddTagDialog by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFAFAFA))
            .statusBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top Action Bar (Exact match to Screenshot 4 & 6)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CircleIconButton(icon = Icons.AutoMirrored.Filled.ArrowBack, onClick = onBack)
                    CircleIconButton(icon = Icons.AutoMirrored.Filled.FormatListBulleted, onClick = onOpenTocSheet)
                }

                if (isEditing) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircleIconButton(
                            icon = Icons.AutoMirrored.Filled.Undo,
                            onClick = { editIntro = note.introParagraph }
                        )
                        CircleIconButton(
                            icon = Icons.AutoMirrored.Filled.Redo,
                            onClick = {}
                        )
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = CardWhite,
                            shadowElevation = 2.dp,
                            modifier = Modifier
                                .height(42.dp)
                                .clickable { onSaveEditedNote(editTitle, editQuote, editIntro) }
                        ) {
                            Box(
                                modifier = Modifier.padding(horizontal = 18.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("完成", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            }
                        }
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        CircleIconButton(icon = Icons.Default.Share, onClick = {})
                        CircleIconButton(icon = Icons.Default.MoreVert, onClick = {})
                    }
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 22.dp, end = 22.dp, top = 8.dp, bottom = 120.dp)
            ) {
                // Timestamp
                item {
                    Text(
                        text = note.updatedAt.removeSuffix("更新"),
                        fontSize = 13.sp,
                        color = Color(0xFF9E9E9E)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Title
                item {
                    if (isEditing) {
                        OutlinedTextField(
                            value = editTitle,
                            onValueChange = { editTitle = it },
                            label = { Text("笔记标题") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        Text(
                            text = note.title,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            lineHeight = 32.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                }

                // Tag Pills Row ("+" + tags)
                item {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFF0F0F2),
                            modifier = Modifier
                                .size(28.dp)
                                .clickable { showAddTagDialog = true }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "添加标签",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        note.tags.forEach { tag ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFFF0F0F2)
                            ) {
                                Text(
                                    text = tag,
                                    fontSize = 12.sp,
                                    color = Color(0xFF757575),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                }

                // Warm Orange Marker Highlighted Key Takeaway Sentence (Exact Screenshot 4 style)
                item {
                    if (isEditing) {
                        OutlinedTextField(
                            value = editQuote,
                            onValueChange = { editQuote = it },
                            label = { Text("高亮核心金句") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        val annotated = buildAnnotatedString {
                            withStyle(
                                style = SpanStyle(
                                    background = HighlightWarm,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp
                                )
                            ) {
                                append(note.highlightedQuote)
                            }
                        }
                        Text(
                            text = annotated,
                            lineHeight = 28.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(18.dp))
                    HorizontalDivider(color = Color(0xFFE5E5E5), thickness = 1.dp)
                    Spacer(modifier = Modifier.height(18.dp))
                }

                // Intro Paragraph
                item {
                    if (isEditing) {
                        OutlinedTextField(
                            value = editIntro,
                            onValueChange = { editIntro = it },
                            label = { Text("导读与正文内容") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        Text(
                            text = note.introParagraph,
                            fontSize = 16.sp,
                            color = Color(0xFF262626),
                            lineHeight = 27.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                }

                // Structured Chapters ("📋 全书核心框架", "🔍 第1章：基本概念")
                items(note.chapters, key = { it.id }) { chapter ->
                    Column(modifier = Modifier.padding(bottom = 24.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = chapter.emoji, fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = chapter.title,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = chapter.bodyParagraph,
                            fontSize = 16.sp,
                            color = Color(0xFF262626),
                            lineHeight = 27.sp
                        )
                    }
                }

                // Embedded Structured Table Card (Exact Screenshot 4 bottom table preview)
                note.comparisonTable?.let { tableData ->
                    item {
                        Text(
                            text = tableData.title,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = Color(0xFFF3F4F6),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "表格",
                                        fontSize = 14.sp,
                                        color = TextSecondary,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Icon(
                                        imageVector = Icons.Default.OpenInFull,
                                        contentDescription = "展开表格",
                                        tint = TextSecondary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Surface(
                                    color = CardWhite,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Column {
                                        // Header Row
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color(0xFFF9FAFB))
                                                .padding(12.dp)
                                        ) {
                                            tableData.headers.forEachIndexed { idx, h ->
                                                Text(
                                                    text = h,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = TextSecondary,
                                                    modifier = Modifier.weight(if (idx == 0) 0.35f else 0.65f)
                                                )
                                            }
                                        }
                                        HorizontalDivider(color = Color(0xFFEEEEEE))
                                        tableData.rows.forEach { r ->
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(12.dp)
                                            ) {
                                                r.forEachIndexed { idx, cell ->
                                                    Text(
                                                        text = cell,
                                                        fontSize = 13.sp,
                                                        color = TextPrimary,
                                                        fontWeight = if (idx == 0) FontWeight.SemiBold else FontWeight.Normal,
                                                        modifier = Modifier.weight(if (idx == 0) 0.35f else 0.65f)
                                                    )
                                                }
                                            }
                                            HorizontalDivider(color = Color(0xFFF3F4F6))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Bottom Floating Pill:
        // In View Mode (Screenshot 4): "问小布" | "编辑"
        // In Edit Mode (Screenshot 6): "格式  |  @  |  图片  |  +"
        if (isEditing) {
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 16.dp)
                    .height(52.dp)
                    .width(240.dp),
                shape = RoundedCornerShape(50),
                color = CardWhite,
                shadowElevation = 10.dp
            ) {
                Row(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "格式",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextSecondary,
                        modifier = Modifier.clickable {
                            editIntro += " — 已套用标准章节格式"
                        }
                    )
                    Icon(
                        imageVector = Icons.Default.AlternateEmail,
                        contentDescription = "@引用",
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                    Icon(
                        imageVector = Icons.Default.Image,
                        contentDescription = "插入图片",
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "更多插入",
                        tint = TextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        } else {
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 18.dp)
                    .width(196.dp)
                    .height(60.dp),
                shape = RoundedCornerShape(50),
                color = CardWhite,
                shadowElevation = 10.dp
            ) {
                Row(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clickable { onOpenAiAssistant() },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Alignment.CenterVertically
                    ) {
                        ColorfulBreenoRibbonIcon(modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.height(2.dp))
                        Text("问小布", fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
                    }
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clickable { onToggleEdit(true) },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "编辑",
                            tint = TextPrimary,
                            modifier = Modifier.size(21.dp)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text("编辑", fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }

        if (showAddTagDialog) {
            var newTagText by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { showAddTagDialog = false },
                title = { Text("添加笔记标签") },
                text = {
                    OutlinedTextField(
                        value = newTagText,
                        onValueChange = { newTagText = it },
                        label = { Text("标签名称") },
                        singleLine = true
                    )
                },
                confirmButton = {
                    Button(onClick = {
                        onAddTag(newTagText)
                        showAddTagDialog = false
                    }) {
                        Text("添加")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddTagDialog = false }) {
                        Text("取消")
                    }
                }
            )
        }
    }
}

/**
 * Screenshot 5: "目录" (Table of Contents) Bottom Sheet
 */
@Composable
fun TocBottomSheetContent(
    note: NoteItem,
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
            .navigationBarsPadding()
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Surface(
                shape = RoundedCornerShape(50),
                color = CardWhite,
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .clickable { onClose() }
            ) {
                Text(
                    text = "关闭",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextPrimary,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)
                )
            }
            Text(
                text = "目录",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        Spacer(modifier = Modifier.height(18.dp))
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = CardWhite,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                note.chapters.forEachIndexed { idx, ch ->
                    var expanded by remember { mutableStateOf(true) }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { expanded = !expanded }
                            .padding(vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(text = ch.emoji, fontSize = 17.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = ch.title,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (idx == 0) SparkOrange else TextPrimary
                            )
                        }
                        if (ch.subItems.isNotEmpty()) {
                            Icon(
                                imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null,
                                tint = TextSecondary
                            )
                        }
                    }

                    if (expanded && ch.subItems.isNotEmpty()) {
                        ch.subItems.forEach { sub ->
                            HorizontalDivider(color = Color(0xFFF2F2F2))
                            Text(
                                text = sub,
                                fontSize = 15.sp,
                                color = TextPrimary,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onClose() }
                                    .padding(start = 18.dp, top = 14.dp, bottom = 14.dp)
                            )
                        }
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(24.dp))
    }
}

/**
 * Screenshot 7: Blurred "+" Creation Overlay
 * - 会议笔记 (large card with two people talking illustration)
 * - 说想法 (left square card) | 写笔记 (right square card with T|)
 * - 更多内容转笔记 (wide pill bar)
 * - Bottom left: Settings gear circle button (opens LLM API Config)
 * - Bottom right: Close X circle button
 */
@Composable
fun PlusCreationBlurredOverlay(
    onDismiss: () -> Unit,
    onClickSettings: () -> Unit,
    onTriggerAction: (String) -> Unit,
    onClickMoreConvert: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xEBFFFFFF))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onDismiss() }
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. 会议笔记 Card
            Surface(
                shape = RoundedCornerShape(26.dp),
                color = CardWhite,
                shadowElevation = 6.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onTriggerAction("会议笔记") }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 22.dp, vertical = 22.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "会议笔记",
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "会议、讨论、课堂，智能总结\n要点，沉淀核心主题",
                            fontSize = 13.sp,
                            color = TextSecondary,
                            lineHeight = 19.sp
                        )
                    }
                    MeetingDiscussionIllustration(modifier = Modifier.size(width = 110.dp, height = 74.dp))
                }
            }

            // 2. 说想法 & 写笔记 Two Square Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(26.dp),
                    color = CardWhite,
                    shadowElevation = 6.dp,
                    modifier = Modifier
                        .weight(1f)
                        .height(132.dp)
                        .clickable { onTriggerAction("说想法") }
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(20.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.Top) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = null,
                                tint = TextPrimary,
                                modifier = Modifier.size(28.dp)
                            )
                            Text("✦", color = SparkOrange, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text(
                                text = "说想法",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "去除语气词和停顿",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }

                Surface(
                    shape = RoundedCornerShape(26.dp),
                    color = CardWhite,
                    shadowElevation = 6.dp,
                    modifier = Modifier
                        .weight(1f)
                        .height(132.dp)
                        .clickable { onTriggerAction("写笔记") }
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(20.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "T",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "|",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = SparkOrange
                            )
                        }
                        Column {
                            Text(
                                text = "写笔记",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "轻松记录，快捷编辑",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            // 3. 更多内容转笔记 Pill Bar
            Surface(
                shape = RoundedCornerShape(50),
                color = CardWhite,
                shadowElevation = 6.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .clickable { onClickMoreConvert() }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // 3 overlapping colorful circles
                    Box(modifier = Modifier.width(68.dp).height(28.dp)) {
                        Box(
                            modifier = Modifier
                                .size(26.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFEC4899)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("B", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Box(
                            modifier = Modifier
                                .offset(x = 18.dp)
                                .size(26.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFEF4444)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Link, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                        }
                        Box(
                            modifier = Modifier
                                .offset(x = 36.dp)
                                .size(26.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF3B82F6)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Image, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "更多内容转笔记",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
            }

            // 4. Bottom Row: Left Settings Gear Circle + Right Close X Circle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    modifier = Modifier
                        .size(58.dp)
                        .clickable { onClickSettings() },
                    shape = CircleShape,
                    color = CardWhite,
                    shadowElevation = 8.dp
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "API 设置",
                            tint = TextPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Surface(
                    modifier = Modifier
                        .size(58.dp)
                        .clickable { onDismiss() },
                    shape = CircleShape,
                    color = CardWhite,
                    shadowElevation = 8.dp
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "关闭",
                            tint = TextPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Screenshot 8: "更多内容转笔记" Bottom Sheet
 * - 链接 (小红书、B站、公众号等) | 扫描 (扫描纸质资料、书籍)
 * - 图片/拍照 | 文档 | 音频
 * - 应用: 小布记忆 (基于记忆素材，智能创作笔记)
 */
@Composable
fun MoreContentToNoteSheet(
    onClose: () -> Unit,
    onClickLink: () -> Unit,
    onClickScan: () -> Unit,
    onClickImage: () -> Unit,
    onClickDocument: () -> Unit,
    onClickAudio: () -> Unit,
    onClickBreenoMemory: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
            .navigationBarsPadding()
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Surface(
                shape = RoundedCornerShape(50),
                color = CardWhite,
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .clickable { onClose() }
            ) {
                Text(
                    text = "关闭",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextPrimary,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)
                )
            }
            Text(
                text = "更多内容转笔记",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Row 1: 链接 | 扫描
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = CardWhite,
                modifier = Modifier
                    .weight(1f)
                    .height(116.dp)
                    .clickable { onClickLink() }
            ) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Icon(
                        imageVector = Icons.Default.Link,
                        contentDescription = null,
                        tint = SparkOrange,
                        modifier = Modifier.size(28.dp).align(Alignment.End)
                    )
                    Column {
                        Text("链接", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text("小红书、B站、公众号等", fontSize = 11.sp, color = TextSecondary)
                    }
                }
            }

            Surface(
                shape = RoundedCornerShape(22.dp),
                color = CardWhite,
                modifier = Modifier
                    .weight(1f)
                    .height(116.dp)
                    .clickable { onClickScan() }
            ) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Icon(
                        imageVector = Icons.Default.DocumentScanner,
                        contentDescription = null,
                        tint = SparkOrange,
                        modifier = Modifier.size(26.dp).align(Alignment.End)
                    )
                    Column {
                        Text("扫描", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text("扫描纸质资料、书籍", fontSize = 11.sp, color = TextSecondary)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Row 2: 图片/拍照 | 文档 | 音频
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SmallConvertTile(
                title = "图片/拍照",
                icon = Icons.Default.Image,
                iconBg = Color(0xFF2563EB),
                onClick = onClickImage,
                modifier = Modifier.weight(1f)
            )
            SmallConvertTile(
                title = "文档",
                icon = Icons.Default.Description,
                iconBg = Color(0xFF0EA5E9),
                onClick = onClickDocument,
                modifier = Modifier.weight(1f)
            )
            SmallConvertTile(
                title = "音频",
                icon = Icons.Default.AudioFile,
                iconBg = SparkOrange,
                onClick = onClickAudio,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))
        Text("应用", fontSize = 13.sp, color = TextSecondary, fontWeight = FontWeight.Medium)
        Spacer(modifier = Modifier.height(10.dp))

        Surface(
            shape = RoundedCornerShape(22.dp),
            color = CardWhite,
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onClickBreenoMemory() }
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFFF5F3FF),
                    modifier = Modifier.size(46.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        ColorfulBreenoRibbonIcon(modifier = Modifier.size(26.dp))
                    }
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("小布记忆", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text("基于记忆素材，智能创作笔记", fontSize = 12.sp, color = TextSecondary)
                }
                Icon(
                    imageVector = Icons.Default.KeyboardArrowRight,
                    contentDescription = null,
                    tint = TextSecondary
                )
            }
        }
        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun SmallConvertTile(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconBg: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = CardWhite,
        modifier = modifier
            .height(98.dp)
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(iconBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = title, tint = Color.White, modifier = Modifier.size(22.dp))
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        }
    }
}

/**
 * Screenshot 9: "Hi，我是你的笔记助手" Full-Screen AI Assistant
 * - Cute black furry mascot with glasses and magic wand
 * - Greeting: "Hi，我是你的笔记助手" / "可以和我聊聊你的创作灵感"
 * - Above input bar chips: "检索范围 ▼" | "笔记创作" | "笔记洞察" | "知识框架"
 * - Bottom input pill: "和 AI 聊聊你的想法" + voice wave icon + plus icon
 * - Top right: History icon + New Chat / API Settings button
 */
@Composable
fun AiAssistantFullScreen(
    state: NotesAppState,
    onBack: () -> Unit,
    onOpenApiSettings: () -> Unit,
    onClearHistory: () -> Unit,
    onSendMessage: (String, String) -> Unit
) {
    var inputPrompt by remember { mutableStateOf("") }
    var scopeLabel by remember { mutableStateOf("全部笔记") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgGray)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircleIconButton(icon = Icons.AutoMirrored.Filled.ArrowBack, onClick = onBack)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = CardWhite,
                    shadowElevation = 1.dp,
                    modifier = Modifier
                        .height(42.dp)
                        .clickable { onOpenApiSettings() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = null, tint = SparkOrange, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (state.llmConfig.apiKey.isBlank()) "接入大模型API" else state.llmConfig.modelName,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                }
                CircleIconButton(icon = Icons.Default.History, onClick = onClearHistory)
                CircleIconButton(icon = Icons.Default.Add, onClick = onClearHistory)
            }
        }

        // Main Body: Greeting Mascot + Chat Stream
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 22.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Column(modifier = Modifier.padding(top = 12.dp, bottom = 10.dp)) {
                    CuteBlackFurryMascot(modifier = Modifier.size(120.dp))
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Hi，我是你的笔记助手",
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "可以和我聊聊你的创作灵感",
                        fontSize = 15.sp,
                        color = TextSecondary
                    )
                }
            }

            items(state.chatMessages, key = { it.id }) { msg ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (msg.isUser) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        shape = RoundedCornerShape(
                            topStart = 20.dp,
                            topEnd = 20.dp,
                            bottomStart = if (msg.isUser) 20.dp else 6.dp,
                            bottomEnd = if (msg.isUser) 6.dp else 20.dp
                        ),
                        color = if (msg.isUser) Color(0xFF141414) else CardWhite,
                        shadowElevation = 1.dp,
                        modifier = Modifier.fillMaxWidth(0.88f)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = msg.content,
                                fontSize = 15.sp,
                                color = if (msg.isUser) Color.White else TextPrimary,
                                lineHeight = 23.sp
                            )
                        }
                    }
                }
            }

            if (state.isAiThinking) {
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 8.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                            color = SparkOrange
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("小布笔记助手正在思考...", fontSize = 13.sp, color = TextSecondary)
                    }
                }
            }
        }

        // Action Chips Row ("检索范围 ▼" | "笔记创作" | "笔记洞察" | "题库自测")
        LazyRow(
            contentPadding = PaddingValues(horizontal = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            item {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color(0xFFEDEDEF),
                    modifier = Modifier.clickable {
                        scopeLabel = if (scopeLabel == "全部笔记") "当前笔记" else "全部笔记"
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(5.dp))
                        Text("检索范围: $scopeLabel ▼", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
                    }
                }
            }
            item {
                AssistantChipPill("💬 笔记创作") {
                    onSendMessage("请帮我基于工程经济学核心概念，生成一篇包含高亮金句、章节目录与对比表格的复习笔记。", scopeLabel)
                }
            }
            item {
                AssistantChipPill("📑 笔记洞察") {
                    onSendMessage("请扫描我现有的全部笔记，提炼出 3 条跨学科的灵光一刻核心洞察。", scopeLabel)
                }
            }
            item {
                AssistantChipPill("📊 生成对比表") {
                    onSendMessage("请将我笔记中的易混概念整理成清晰的对比表格。", scopeLabel)
                }
            }
        }

        // Bottom Input Pill ("和 AI 聊聊你的想法")
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 10.dp)
                .height(58.dp),
            shape = RoundedCornerShape(50),
            color = CardWhite,
            shadowElevation = 4.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                androidx.compose.foundation.text.BasicTextField(
                    value = inputPrompt,
                    onValueChange = { inputPrompt = it },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    decorationBox = { inner ->
                        if (inputPrompt.isEmpty()) {
                            Text("和 AI 聊聊你的想法", fontSize = 15.sp, color = Color(0xFF9E9E9E))
                        }
                        inner()
                    }
                )
                Icon(
                    imageVector = Icons.Default.GraphicEq,
                    contentDescription = "语音输入",
                    tint = TextPrimary,
                    modifier = Modifier
                        .size(26.dp)
                        .clickable {
                            if (inputPrompt.isNotBlank()) {
                                onSendMessage(inputPrompt, scopeLabel)
                                inputPrompt = ""
                            } else {
                                onSendMessage("帮我梳理一下工程经济学和高等数学极限的核心复习重点", scopeLabel)
                            }
                        }
                )
                Spacer(modifier = Modifier.width(12.dp))
                Surface(
                    shape = CircleShape,
                    color = if (inputPrompt.isNotBlank()) TextPrimary else Color.Transparent,
                    modifier = Modifier
                        .size(28.dp)
                        .border(1.8.dp, TextPrimary, CircleShape)
                        .clickable {
                            if (inputPrompt.isNotBlank()) {
                                onSendMessage(inputPrompt, scopeLabel)
                                inputPrompt = ""
                            } else {
                                onOpenApiSettings()
                            }
                        }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (inputPrompt.isNotBlank()) Icons.AutoMirrored.Filled.ArrowForward else Icons.Default.Add,
                            contentDescription = "发送",
                            tint = if (inputPrompt.isNotBlank()) Color.White else TextPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AssistantChipPill(label: String, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(50),
        color = Color(0xFFEDEDEF),
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            text = label,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = TextPrimary,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp)
        )
    }
}

/**
 * Custom LLM API Configuration Dialog (Supports DeepSeek, Qwen, OpenAI, Moonshot, SiliconFlow, etc.)
 */
@Composable
fun LlmApiSettingsDialog(
    currentConfig: LlmApiConfig,
    onDismiss: () -> Unit,
    onSave: (LlmApiConfig) -> Unit
) {
    var baseUrl by remember { mutableStateOf(currentConfig.baseUrl) }
    var apiKey by remember { mutableStateOf(currentConfig.apiKey) }
    var modelName by remember { mutableStateOf(currentConfig.modelName) }
    var systemPrompt by remember { mutableStateOf(currentConfig.systemPrompt) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("接入自定义大模型 API", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "支持所有兼容 OpenAI 格式的大模型接口（一键填入预设或自行修改）：",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = {
                            baseUrl = "https://api.deepseek.com/v1"
                            modelName = "deepseek-chat"
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("DeepSeek", fontSize = 11.sp)
                    }
                    OutlinedButton(
                        onClick = {
                            baseUrl = "https://dashscope.aliyuncs.com/compatible-mode/v1"
                            modelName = "qwen-plus"
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("通义千问", fontSize = 11.sp)
                    }
                    OutlinedButton(
                        onClick = {
                            baseUrl = "https://api.siliconflow.cn/v1"
                            modelName = "deepseek-ai/DeepSeek-V3"
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("硅基流动", fontSize = 11.sp)
                    }
                }

                OutlinedTextField(
                    value = baseUrl,
                    onValueChange = { baseUrl = it },
                    label = { Text("API Base URL") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    label = { Text("API Key (sk-...)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = modelName,
                    onValueChange = { modelName = it },
                    label = { Text("模型名称 (Model)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = systemPrompt,
                    onValueChange = { systemPrompt = it },
                    label = { Text("系统提示词 (System Prompt)") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        LlmApiConfig(
                            providerName = "自定义大模型",
                            baseUrl = baseUrl,
                            apiKey = apiKey,
                            modelName = modelName,
                            systemPrompt = systemPrompt
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = TextPrimary)
            ) {
                Text("保存并生效", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("取消")
            }
        }
    )
}

@Composable
fun CircleIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .size(44.dp)
            .clickable { onClick() },
        shape = CircleShape,
        color = CardWhite,
        shadowElevation = 1.5.dp
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = TextPrimary,
                modifier = Modifier.size(21.dp)
            )
        }
    }
}

/**
 * Custom Canvas drawing for the Orange 6-ray Spark Asterisk ("✳ 灵光一刻")
 */
@Composable
fun SparkAsteriskIcon(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val r = size.minDimension * 0.45f
        val stroke = size.minDimension * 0.16f
        for (angle in listOf(0f, 60f, 120f)) {
            val rad = Math.toRadians(angle.toDouble())
            val dx = (r * Math.cos(rad)).toFloat()
            val dy = (r * Math.sin(rad)).toFloat()
            drawLine(
                color = SparkOrange,
                start = Offset(cx - dx, cy - dy),
                end = Offset(cx + dx, cy + dy),
                strokeWidth = stroke,
                cap = androidx.compose.ui.graphics.StrokeCap.Round
            )
        }
    }
}

/**
 * Custom Canvas drawing for the ColorOS 17 Breeno 4-color Infinity Ribbon Icon
 */
@Composable
fun ColorfulBreenoRibbonIcon(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val stroke = size.minDimension * 0.14f
        val pad = stroke
        drawRoundRect(
            brush = Brush.sweepGradient(
                colors = listOf(
                    Color(0xFFF97316),
                    Color(0xFF10B981),
                    Color(0xFF3B82F6),
                    Color(0xFFA855F7),
                    Color(0xFFF97316)
                )
            ),
            topLeft = Offset(pad, pad),
            size = Size(size.width - pad * 2, size.height - pad * 2),
            cornerRadius = CornerRadius(size.minDimension * 0.35f, size.minDimension * 0.35f),
            style = Stroke(width = stroke)
        )
        drawCircle(
            color = Color(0xFFF97316),
            radius = stroke * 0.65f,
            center = Offset(size.width / 2f, size.height / 2f)
        )
    }
}

/**
 * Custom Canvas drawing for the cute black furry mascot with round glasses and magic wand (Screenshot 9)
 */
@Composable
fun CuteBlackFurryMascot(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Soft shadow underneath
        drawOval(
            color = Color(0x18000000),
            topLeft = Offset(w * 0.18f, h * 0.86f),
            size = Size(w * 0.56f, h * 0.08f)
        )

        // Main fluffy dark body
        drawRoundRect(
            color = Color(0xFF1A1A1A),
            topLeft = Offset(w * 0.12f, h * 0.22f),
            size = Size(w * 0.64f, h * 0.58f),
            cornerRadius = CornerRadius(w * 0.28f, w * 0.28f)
        )

        // Round golden-rimmed glasses (left & right lens)
        val leftCenter = Offset(w * 0.38f, h * 0.46f)
        val rightCenter = Offset(w * 0.58f, h * 0.45f)
        val lensR = w * 0.095f

        drawCircle(color = Color.White, radius = lensR * 0.85f, center = leftCenter)
        drawCircle(color = Color.White, radius = lensR * 0.85f, center = rightCenter)
        drawCircle(color = Color(0xFF141414), radius = lensR * 0.48f, center = leftCenter)
        drawCircle(color = Color(0xFF141414), radius = lensR * 0.48f, center = rightCenter)
        drawCircle(color = Color.White, radius = lensR * 0.16f, center = Offset(leftCenter.x - 3f, leftCenter.y - 3f))
        drawCircle(color = Color.White, radius = lensR * 0.16f, center = Offset(rightCenter.x - 3f, rightCenter.y - 3f))

        drawCircle(
            color = Color(0xFFD4B483),
            radius = lensR,
            center = leftCenter,
            style = Stroke(width = 4f)
        )
        drawCircle(
            color = Color(0xFFD4B483),
            radius = lensR,
            center = rightCenter,
            style = Stroke(width = 4f)
        )

        // Magic pen / wand in right hand with golden sparkles
        drawLine(
            color = Color(0xFF262626),
            start = Offset(w * 0.68f, h * 0.58f),
            end = Offset(w * 0.88f, h * 0.28f),
            strokeWidth = 7f,
            cap = androidx.compose.ui.graphics.StrokeCap.Round
        )
        drawLine(
            color = Color(0xFFF59E0B),
            start = Offset(w * 0.84f, h * 0.34f),
            end = Offset(w * 0.89f, h * 0.26f),
            strokeWidth = 7f,
            cap = androidx.compose.ui.graphics.StrokeCap.Round
        )
        // Golden sparkles arc
        drawCircle(color = Color(0xFFFBBF24), radius = 5f, center = Offset(w * 0.90f, h * 0.22f))
        drawCircle(color = Color(0xFFFDE68A), radius = 4f, center = Offset(w * 0.78f, h * 0.14f))
        drawCircle(color = Color(0xFFF59E0B), radius = 3.5f, center = Offset(w * 0.64f, h * 0.12f))
    }
}

/**
 * Custom Canvas illustration for "会议笔记" Card (Screenshot 7)
 */
@Composable
fun MeetingDiscussionIllustration(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        // Whiteboard / screen frame in background
        drawRoundRect(
            color = Color(0xFFF3F4F6),
            topLeft = Offset(w * 0.22f, h * 0.08f),
            size = Size(w * 0.56f, h * 0.54f),
            cornerRadius = CornerRadius(12f, 12f)
        )
        drawRoundRect(
            color = Color(0xFF1F2937),
            topLeft = Offset(w * 0.22f, h * 0.08f),
            size = Size(w * 0.56f, h * 0.54f),
            cornerRadius = CornerRadius(12f, 12f),
            style = Stroke(width = 3.5f)
        )
        // Person 1 (left with orange hair)
        drawCircle(
            color = SparkOrange,
            radius = h * 0.18f,
            center = Offset(w * 0.22f, h * 0.56f)
        )
        // Person 2 (right)
        drawCircle(
            color = Color(0xFFD1D5DB),
            radius = h * 0.18f,
            center = Offset(w * 0.78f, h * 0.56f)
        )
    }
}
