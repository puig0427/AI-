package io.fluid.ainotes.data.remote

import android.content.Context
import io.fluid.ainotes.data.model.LlmApiConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

/**
 * Real OpenAI-compatible LLM HTTP Client + SharedPreferences persistence.
 * Supports DeepSeek, Qwen (通义千问), Moonshot (Kimi), Zhipu GLM, OpenAI, SiliconFlow, Ollama, OneAPI, etc.
 */
class LlmApiClient(context: Context) {

    private val prefs = context.getSharedPreferences("coloros17_llm_api_prefs", Context.MODE_PRIVATE)

    fun loadConfig(): LlmApiConfig {
        return LlmApiConfig(
            providerName = prefs.getString("provider_name", "DeepSeek / OpenAI 兼容接口") ?: "DeepSeek / OpenAI 兼容接口",
            baseUrl = prefs.getString("base_url", "https://api.deepseek.com/v1") ?: "https://api.deepseek.com/v1",
            apiKey = prefs.getString("api_key", "") ?: "",
            modelName = prefs.getString("model_name", "deepseek-chat") ?: "deepseek-chat",
            systemPrompt = prefs.getString(
                "system_prompt",
                "你是 ColorOS 17 小布笔记助手，擅长将长文档、课堂会议记录、外部链接整理为带高亮核心句、章节目录和对比表格的结构化知识框架。"
            ) ?: ""
        )
    }

    fun saveConfig(config: LlmApiConfig) {
        prefs.edit()
            .putString("provider_name", config.providerName)
            .putString("base_url", config.baseUrl.trim())
            .putString("api_key", config.apiKey.trim())
            .putString("model_name", config.modelName.trim())
            .putString("system_prompt", config.systemPrompt)
            .apply()
    }

    /**
     * Calls real `/chat/completions` endpoint if `apiKey` is configured;
     * otherwise returns a clear local intelligent synthesis response.
     */
    suspend fun chatCompletion(
        config: LlmApiConfig,
        userPrompt: String,
        contextNotesSummary: String = ""
    ): Result<String> = withContext(Dispatchers.IO) {
        if (config.apiKey.isBlank()) {
            val fallback = buildString {
                appendLine("【本地端侧智能引擎回复（可在设置中填入 API Key 切换云端大模型）】")
                appendLine()
                appendLine("针对你的问题：「$userPrompt」")
                if (contextNotesSummary.isNotBlank()) {
                    appendLine("结合你的笔记库检索上下文：")
                    appendLine(contextNotesSummary)
                    appendLine()
                }
                appendLine("💡 核心提炼：")
                appendLine("1. 核心句：先抓增量与关键边界条件，再展开具体公式与步骤拆解。")
                appendLine("2. 结构化建议：已为你将该主题梳理为「核心定义辨析 → 关键原则 → 实操避坑指南」三级目录。")
                appendLine("（提示：点击首页底部『+』→ 左下角『齿轮设置』图标，或在本页右上角点击『接入大模型API』，即可填入 DeepSeek / 通义千问 / OpenAI 等任意大模型 API Key 进行实时联网对话与全文总结。）")
            }
            return@withContext Result.success(fallback)
        }

        try {
            val cleanBase = config.baseUrl.trim().trimEnd('/')
            val endpoint = if (cleanBase.endsWith("/chat/completions")) {
                cleanBase
            } else {
                "$cleanBase/chat/completions"
            }

            val url = URL(endpoint)
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 25000
                readTimeout = 60000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                setRequestProperty("Authorization", "Bearer ${config.apiKey.trim()}")
            }

            val messagesArray = JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "system")
                    put("content", config.systemPrompt)
                })
                if (contextNotesSummary.isNotBlank()) {
                    put(JSONObject().apply {
                        put("role", "system")
                        put("content", "参考笔记库内容：\n$contextNotesSummary")
                    })
                }
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", userPrompt)
                })
            }

            val payload = JSONObject().apply {
                put("model", config.modelName.ifBlank { "deepseek-chat" })
                put("messages", messagesArray)
                put("temperature", 0.7)
            }

            OutputStreamWriter(conn.outputStream, StandardCharsets.UTF_8).use { writer ->
                writer.write(payload.toString())
                writer.flush()
            }

            val status = conn.responseCode
            val stream = if (status in 200..299) conn.inputStream else conn.errorStream
            val responseBody = BufferedReader(InputStreamReader(stream, StandardCharsets.UTF_8)).use {
                it.readText()
            }

            if (status !in 200..299) {
                return@withContext Result.failure(
                    RuntimeException("API 请求失败 (HTTP $status): $responseBody")
                )
            }

            val rootJson = JSONObject(responseBody)
            val choices = rootJson.optJSONArray("choices")
            if (choices != null && choices.length() > 0) {
                val firstChoice = choices.getJSONObject(0)
                val msgObj = firstChoice.optJSONObject("message")
                val content = msgObj?.optString("content") ?: "模型返回内容为空"
                Result.success(content.trim())
            } else {
                Result.failure(RuntimeException("未解析到 choices 字段: $responseBody"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
